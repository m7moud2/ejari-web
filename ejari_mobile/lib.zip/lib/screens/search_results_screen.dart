import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/property_card.dart';
import '../services/data_service.dart';
import 'property_details_screen.dart';
import 'booking_screen.dart';

class SearchResultsScreen extends StatefulWidget {
  final String query;
  final Map<String, dynamic>? filters;

  const SearchResultsScreen({
    super.key,
    required this.query,
    this.filters,
  });

  @override
  State<SearchResultsScreen> createState() => _SearchResultsScreenState();
}

class _SearchResultsScreenState extends State<SearchResultsScreen> {
  List<Map<String, dynamic>> _results = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _performSearch();
  }

  Future<void> _performSearch() async {
    // Simulate search delay
    await Future.delayed(const Duration(milliseconds: 500));

    final allProperties = await DataService.getAllProperties();
    
    final results = allProperties.where((property) {
      // 1. Search by Query (Title or Location)
      final title = property['title']?.toString().toLowerCase() ?? '';
      final location = property['location']?.toString().toLowerCase() ?? '';
      final query = widget.query.toLowerCase();
      
      bool matchesQuery = title.contains(query) || location.contains(query);
      
      if (!matchesQuery) return false;

      // 2. Apply Filters (if any)
      if (widget.filters != null) {
        final filters = widget.filters!;
        
        // Price Range
        final priceStr = property['price']?.toString().replaceAll(',', '') ?? '0';
        final price = double.tryParse(priceStr) ?? 0.0;

        if (filters['minPrice'] != null) {
          if (price < filters['minPrice']) return false;
        }
        if (filters['maxPrice'] != null) {
          if (price > filters['maxPrice']) return false;
        }

        // Bedrooms
        if (filters['beds'] != null) {
          final beds = int.tryParse(property['beds']?.toString().split(' ').first ?? '0') ?? 0;
          if (beds < filters['beds']) return false;
        }

        // Bathrooms
        if (filters['baths'] != null) {
          final baths = int.tryParse(property['baths']?.toString().split(' ').first ?? '0') ?? 0;
          if (baths < filters['baths']) return false;
        }

        // Property Type
        if (filters['type'] != null) {
          final type = property['type']?.toString().toLowerCase() ?? '';
          if (!type.contains(filters['type'].toString().toLowerCase())) return false;
        }

        // Amenities
        if (filters['amenities'] != null) {
          final List<String> requiredAmenities = List<String>.from(filters['amenities']);
          final propertyAmenities = List<String>.from(property['amenities'] ?? []);
          
          for (var amenity in requiredAmenities) {
            if (!propertyAmenities.contains(amenity)) return false;
          }
        }
      }

      return true;
    }).toList();

    if (mounted) {
      setState(() {
        _results = results;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('نتائج البحث: ${widget.query}'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _results.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.search_off, size: 80, color: Colors.grey[300]),
                      const SizedBox(height: 16),
                      const Text(
                        'لا توجد نتائج مطابقة لبحثك',
                        style: TextStyle(fontSize: 18, color: AppTheme.textSecondary),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'حاول استخدام كلمات مفتاحية مختلفة',
                        style: TextStyle(color: AppTheme.textSecondary),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _results.length,
                  itemBuilder: (context, index) {
                    final property = _results[index];
                    return PropertyCard(
                      id: property['id'] ?? '0',
                      title: property['title'] ?? '',
                      price: property['price'] ?? '0',
                      location: property['location'] ?? '',
                      image: property['image'] ?? 'assets/images/home1.jpg',
                      beds: property['beds'] ?? '0',
                      baths: property['baths'] ?? '0',
                      area: property['area'] ?? '0',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PropertyDetailsScreen(property: property),
                          ),
                        );
                      },
                      onBook: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BookingScreen(
                              itemType: 'property',
                              itemData: property,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
    );
  }
}
