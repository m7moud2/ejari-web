import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'chat_screen.dart';
import '../services/auth_service.dart';
import 'package:url_launcher/url_launcher.dart';

class MyServiceRequestsScreen extends StatefulWidget {
  const MyServiceRequestsScreen({super.key});

  @override
  State<MyServiceRequestsScreen> createState() => _MyServiceRequestsScreenState();
}

class _MyServiceRequestsScreenState extends State<MyServiceRequestsScreen> {
  // Demo data - في التطبيق الحقيقي سيتم جلبها من قاعدة البيانات
  final List<Map<String, dynamic>> _requests = [
    {
      'id': 'SR001',
      'service': 'تنظيف شامل',
      'provider': 'شركة النظافة المثالية',
      'date': '2023-12-05',
      'time': '10:00 ص',
      'status': 'pending', // pending, accepted, in_progress, completed, cancelled
      'price': '300',
      'address': 'شقة 12، المعادي',
      'notes': 'تنظيف شامل للشقة بعد الانتقال',
    },
    {
      'id': 'SR002',
      'service': 'صيانة تكييف',
      'provider': 'مركز الصيانة السريع',
      'date': '2023-12-03',
      'time': '02:00 م',
      'status': 'in_progress',
      'price': '150',
      'address': 'فيلا 5، الشيخ زايد',
      'notes': 'صيانة دورية للتكييف',
    },
    {
      'id': 'SR003',
      'service': 'نقل أثاث',
      'provider': 'شركة النقل الآمن',
      'date': '2023-12-01',
      'time': '09:00 ص',
      'status': 'completed',
      'price': '500',
      'address': 'من المعادي إلى مدينة نصر',
      'notes': 'نقل أثاث غرفة نوم',
      'rating': 5,
    },
  ];

  String _selectedFilter = 'all'; // all, pending, in_progress, completed

  @override
  Widget build(BuildContext context) {
    final filteredRequests = _selectedFilter == 'all'
        ? _requests
        : _requests.where((r) => r['status'] == _selectedFilter).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('طلبات الخدمات'),
      ),
      body: Column(
        children: [
          // Filter Tabs
          Container(
            padding: const EdgeInsets.all(16),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildFilterChip('الكل', 'all', _requests.length),
                  _buildFilterChip('قيد الانتظار', 'pending', _requests.where((r) => r['status'] == 'pending').length),
                  _buildFilterChip('جاري التنفيذ', 'in_progress', _requests.where((r) => r['status'] == 'in_progress').length),
                  _buildFilterChip('مكتمل', 'completed', _requests.where((r) => r['status'] == 'completed').length),
                ],
              ),
            ),
          ),

          // Requests List
          Expanded(
            child: filteredRequests.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: filteredRequests.length,
                    itemBuilder: (context, index) => _buildRequestCard(filteredRequests[index]),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, String value, int count) {
    final isSelected = _selectedFilter == value;
    return GestureDetector(
      onTap: () => setState(() => _selectedFilter = value),
      child: Container(
        margin: const EdgeInsets.only(left: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryColor : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: isSelected ? AppTheme.primaryColor : Colors.grey[300]!),
        ),
        child: Row(
          children: [
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : AppTheme.textSecondary,
                fontWeight: FontWeight.bold,
              ),
            ),
            if (count > 0) ...[
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: isSelected ? Colors.white : AppTheme.primaryColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '$count',
                  style: TextStyle(
                    color: isSelected ? AppTheme.primaryColor : Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildRequestCard(Map<String, dynamic> request) {
    final status = request['status'];
    Color statusColor;
    String statusText;
    IconData statusIcon;

    switch (status) {
      case 'pending':
        statusColor = Colors.orange;
        statusText = 'قيد الانتظار';
        statusIcon = Icons.access_time;
        break;
      case 'accepted':
        statusColor = Colors.blue;
        statusText = 'مقبول';
        statusIcon = Icons.check_circle_outline;
        break;
      case 'in_progress':
        statusColor = Colors.purple;
        statusText = 'جاري التنفيذ';
        statusIcon = Icons.engineering;
        break;
      case 'completed':
        statusColor = Colors.green;
        statusText = 'مكتمل';
        statusIcon = Icons.check_circle;
        break;
      case 'cancelled':
        statusColor = Colors.red;
        statusText = 'ملغي';
        statusIcon = Icons.cancel;
        break;
      default:
        statusColor = Colors.grey;
        statusText = 'غير معروف';
        statusIcon = Icons.help_outline;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: statusColor.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(statusIcon, color: statusColor, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      statusText,
                      style: TextStyle(
                        color: statusColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Text(
                  'رقم الطلب: ${request['id']}',
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),

          // Content
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  request['service'],
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                _buildInfoRow(Icons.business, request['provider']),
                _buildInfoRow(Icons.calendar_today, '${request['date']} - ${request['time']}'),
                _buildInfoRow(Icons.location_on, request['address']),
                _buildInfoRow(Icons.attach_money, '${request['price']} ج.م'),
                if (request['notes'] != null) ...[
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.note, size: 16, color: AppTheme.textSecondary),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            request['notes'],
                            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                // Rating (if completed)
                if (status == 'completed' && request['rating'] != null) ...[
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Text('تقييمك: ', style: TextStyle(fontWeight: FontWeight.bold)),
                      ...List.generate(
                        5,
                        (index) => Icon(
                          index < request['rating'] ? Icons.star : Icons.star_border,
                          color: Colors.amber,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ],

                // Actions
                const SizedBox(height: 16),
                _buildActions(request),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 16, color: AppTheme.textSecondary),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: AppTheme.textSecondary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActions(Map<String, dynamic> request) {
    final status = request['status'];

    if (status == 'pending') {
      return Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () => _cancelRequest(request),
              style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
              child: const Text('إلغاء الطلب'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => _contactProvider(request),
              icon: const Icon(Icons.phone, size: 18),
              label: const Text('اتصال'),
            ),
          ),
        ],
      );
    } else if (status == 'in_progress') {
      return SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: () => _trackService(request),
          icon: const Icon(Icons.location_searching),
          label: const Text('تتبع الخدمة'),
        ),
      );
    } else if (status == 'completed' && request['rating'] == null) {
      return SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: () => _rateService(request),
          icon: const Icon(Icons.star),
          label: const Text('تقييم الخدمة'),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.amber),
        ),
      );
    }

    return const SizedBox.shrink();
  }

  void _cancelRequest(Map<String, dynamic> request) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إلغاء الطلب'),
        content: const Text('هل أنت متأكد من إلغاء هذا الطلب؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('رجوع'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() => request['status'] = 'cancelled');
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تم إلغاء الطلب')),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('تأكيد الإلغاء'),
          ),
        ],
      ),
    );
  }

  void _contactProvider(Map<String, dynamic> request) {
    const phone = '01280083336';
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(request['provider']),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.phone, color: AppTheme.primaryColor),
              title: const Text(phone),
              onTap: () async {
                Navigator.pop(context);
                final url = Uri.parse('tel:$phone');
                if (await canLaunchUrl(url)) {
                  await launchUrl(url);
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.chat, color: AppTheme.primaryColor),
              title: const Text('محادثة مباشرة'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChatScreen(
                      chatId: request['id'],
                      otherUserName: request['provider'],
                      currentUserId: 'user@keyo.app', // Demo ID for this screen
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _trackService(Map<String, dynamic> request) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('الفني في الطريق إليك - الوصول المتوقع: 15 دقيقة')),
    );
  }

  void _rateService(Map<String, dynamic> request) {
    int rating = 0;
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('تقييم الخدمة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('كيف كانت تجربتك؟'),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  5,
                  (index) => IconButton(
                    icon: Icon(
                      index < rating ? Icons.star : Icons.star_border,
                      color: Colors.amber,
                      size: 32,
                    ),
                    onPressed: () => setDialogState(() => rating = index + 1),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: rating > 0
                  ? () {
                      setState(() => request['rating'] = rating);
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('شكراً لتقييمك!')),
                      );
                    }
                  : null,
              child: const Text('إرسال'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.inbox_outlined, size: 80, color: Colors.grey[300]),
          const SizedBox(height: 16),
          const Text(
            'لا توجد طلبات',
            style: TextStyle(fontSize: 18, color: AppTheme.textSecondary),
          ),
        ],
      ),
    );
  }
}
