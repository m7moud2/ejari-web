import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/contract_service.dart';
import 'signature_screen.dart';

class ContractViewScreen extends StatefulWidget {
  final Map<String, dynamic> bookingDetails;

  const ContractViewScreen({super.key, required this.bookingDetails});

  @override
  State<ContractViewScreen> createState() => _ContractViewScreenState();
}

class _ContractViewScreenState extends State<ContractViewScreen> {
  bool _isSigned = false;
  late String _contractText;

  @override
  void initState() {
    super.initState();
    _generateContract();
  }

  void _generateContract() {
    _contractText = ContractService.generateContract(
      tenantName: widget.bookingDetails['tenantName'] ?? 'المستأجر',
      tenantId: '1234567890', // Should come from profile
      ownerName: widget.bookingDetails['ownerName'] ?? 'المالك',
      propertyTitle: widget.bookingDetails['title'] ?? 'العقار',
      propertyAddress: 'القاهرة، مصر', // Should come from property details
      price: double.tryParse(widget.bookingDetails['price'].toString()) ?? 0.0,
      startDate: widget.bookingDetails['startDate'] != null 
          ? DateTime.parse(widget.bookingDetails['startDate'].toString()) 
          : DateTime.now(),
      endDate: widget.bookingDetails['endDate'] != null 
          ? DateTime.parse(widget.bookingDetails['endDate'].toString()) 
          : DateTime.now().add(const Duration(days: 1)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('العقد الإلكتروني 📜'),
        actions: [
          if (_isSigned)
            IconButton(
              tooltip: 'تحميل نسخة PDF',
              icon: const Icon(Icons.picture_as_pdf),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('جارٍ إنشاء ملف PDF...')),
                );
                Future.delayed(const Duration(seconds: 2), () {
                  if (mounted) {
                     ScaffoldMessenger.of(context).hideCurrentSnackBar();
                     ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text('تم الحفظ في التنزيلات: Contract_Keyo.pdf ✅'),
                          backgroundColor: Colors.green,
                      ),
                    );
                  }
                });
              },
            ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _contractText,
                      style: const TextStyle(fontSize: 14, height: 1.8),
                    ),
                    if (_isSigned) ...[
                      const SizedBox(height: 20),
                      const Divider(),
                      const SizedBox(height: 10),
                      Row(
                        children: const [
                          Icon(Icons.check_circle, color: Colors.green),
                          SizedBox(width: 8),
                          Text(
                            'تم التوقيع إلكترونياً بواسطة المستأجر',
                            style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Text(
                        'بتاريخ: ${DateTime.now().toString().split('.')[0]}',
                        style: const TextStyle(color: Colors.grey, fontSize: 12),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, -5))],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Checkbox(value: _isSigned, onChanged: null), // Checked when signed
                    const Expanded(
                      child: Text(
                        'أقر بأنني قرأت كافة الشروط والأحكام وأوافق عليها.',
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isSigned
                        ? () {
                            Navigator.pop(context, true); // Return true indicating success
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('تم توثيق العقد بنجاح! ✅'), backgroundColor: Colors.green),
                            );
                          }
                        : () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => SignatureScreen(
                                  onSigned: (points) {
                                    setState(() => _isSigned = true);
                                  },
                                ),
                              ),
                            );
                          },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      backgroundColor: _isSigned ? Colors.green : AppTheme.primaryColor,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text(
                      _isSigned ? 'إتمام وتأكيد' : 'توقيع العقد',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
