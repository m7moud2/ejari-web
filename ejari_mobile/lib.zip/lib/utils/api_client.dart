import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiClient {
  static const String tokenKey = 'keyo_token';
  static const String apiBaseUrlKey = 'api_base_url';

  // Get backend API base URL dynamically
  static Future<String> getBaseUrl() async {
    final prefs = await SharedPreferences.getInstance();
    final customUrl = prefs.getString(apiBaseUrlKey);
    if (customUrl != null && customUrl.isNotEmpty) {
      return customUrl;
    }
    
    // Default fallback addresses
    const bool isAndroidEmulator = bool.fromEnvironment('ANDROID_EMULATOR', defaultValue: false);
    if (isAndroidEmulator) {
      return 'http://10.0.2.2:5050/api';
    }
    // For iOS simulator, web browser, or physical device (requires config)
    return 'http://localhost:5050/api';
  }

  // Get stored authentication token
  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(tokenKey);
  }

  // Save authentication token
  static Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(tokenKey, token);
  }

  // Clear authentication token
  static Future<void> clearToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(tokenKey);
  }

  // Common headers builder
  static Future<Map<String, String>> _getHeaders() async {
    final token = await getToken();
    final headers = {
      'Content-Type': 'application/json; charset=utf-8',
      'Accept': 'application/json',
    };
    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  // HTTP GET request
  static Future<http.Response> get(String path) async {
    final baseUrl = await getBaseUrl();
    final uri = Uri.parse('$baseUrl$path');
    final headers = await _getHeaders();
    
    debugPrint('API GET Request: $uri');
    return await http.get(uri, headers: headers).timeout(const Duration(seconds: 10));
  }

  // HTTP POST request
  static Future<http.Response> post(String path, Map<String, dynamic> body) async {
    final baseUrl = await getBaseUrl();
    final uri = Uri.parse('$baseUrl$path');
    final headers = await _getHeaders();
    
    debugPrint('API POST Request: $uri');
    return await http.post(
      uri,
      headers: headers,
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 10));
  }

  // HTTP PUT request
  static Future<http.Response> put(String path, Map<String, dynamic> body) async {
    final baseUrl = await getBaseUrl();
    final uri = Uri.parse('$baseUrl$path');
    final headers = await _getHeaders();
    
    debugPrint('API PUT Request: $uri');
    return await http.put(
      uri,
      headers: headers,
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 10));
  }

  // HTTP DELETE request
  static Future<http.Response> delete(String path) async {
    final baseUrl = await getBaseUrl();
    final uri = Uri.parse('$baseUrl$path');
    final headers = await _getHeaders();
    
    debugPrint('API DELETE Request: $uri');
    return await http.delete(uri, headers: headers).timeout(const Duration(seconds: 10));
  }
}
