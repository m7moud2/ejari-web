import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../screens/advanced_filters_screen.dart';

class EliteNavigationBar extends StatefulWidget {
  final int currentIndex;
  final Function(int) onTap;
  final String role; // 'owner' or 'tenant'

  const EliteNavigationBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
    this.role = 'tenant',
  });

  @override
  State<EliteNavigationBar> createState() => _EliteNavigationBarState();
}

class _EliteNavigationBarState extends State<EliteNavigationBar> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final double height = 80;

    return SizedBox(
      height: 100, // Safe height for BNBCustomPainter and FAB
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // Background Glass with Curve
          Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: Container(
            height: height,
            child: CustomPaint(
              size: Size(size.width, height),
              painter: BNBCustomPainter(context: context),
            ),
          ),
        ),

        // FAB (Center Plus Button)
        Positioned(
          bottom: 35,
          left: (size.width - 70) / 2,
          child: ScaleTransition(
            scale: Tween<double>(begin: 1.0, end: 1.1).animate(
              CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
            ),
            child: Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: widget.role == 'owner' 
                      ? [AppTheme.primaryColor, const Color(0xFF3498DB)]
                      : [AppTheme.accentColor, const Color(0xFFF39C12)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: (widget.role == 'owner' ? AppTheme.primaryColor : AppTheme.accentColor).withOpacity(0.4),
                    blurRadius: 15,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: IconButton(
                icon: Icon(
                  widget.role == 'owner' ? Icons.add : Icons.auto_awesome_rounded, 
                  color: Colors.white, 
                  size: 35
                ),
                onPressed: () {
                  if (widget.role == 'owner') {
                    widget.onTap(2); // Index for Add Property
                  } else {
                    // Open the Smart Search Engine
                    Navigator.push(
                      context, 
                      MaterialPageRoute(builder: (context) => const AdvancedFiltersScreen())
                    );
                  }
                },
              ),
            ),
          ),
        ),

        // Navigation Items
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: Container(
            height: height,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildNavItem(0, Icons.home_rounded, 'الرئيسية'),
                _buildNavItem(1, Icons.apartment_rounded, 'عقارات'),
                const SizedBox(width: 80), // Space for FAB
                _buildNavItem(3, Icons.video_library_rounded, 'ريلز'),
                _buildNavItem(4, Icons.person_rounded, 'حسابي'),
              ],
            ),
          ),
        ),
      ],
    ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, String label) {
    bool isSelected = widget.currentIndex == index;
    return GestureDetector(
      onTap: () => widget.onTap(index),
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        width: 60,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOutBack,
              transform: isSelected ? Matrix4.translationValues(0, -5, 0) : Matrix4.identity(),
              child: Icon(
                icon,
                color: isSelected ? AppTheme.primaryColor : AppTheme.textSecondary,
                size: isSelected ? 30 : 25,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? AppTheme.primaryColor : AppTheme.textSecondary,
                fontSize: 10,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class BNBCustomPainter extends CustomPainter {
  final BuildContext context;
  BNBCustomPainter({required this.context});

  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = Theme.of(context).cardColor
      ..style = PaintingStyle.fill;

    // Shadow
    Path shadowPath = Path();
    shadowPath.moveTo(0, 20);
    shadowPath.quadraticBezierTo(size.width * 0.20, 0, size.width * 0.35, 0);
    shadowPath.quadraticBezierTo(size.width * 0.40, 0, size.width * 0.40, 20);
    shadowPath.arcToPoint(Offset(size.width * 0.60, 20),
        radius: const Radius.circular(20.0), clockwise: false);
    shadowPath.quadraticBezierTo(size.width * 0.60, 0, size.width * 0.65, 0);
    shadowPath.quadraticBezierTo(size.width * 0.80, 0, size.width, 20);
    shadowPath.lineTo(size.width, size.height);
    shadowPath.lineTo(0, size.height);
    shadowPath.close();

    canvas.drawShadow(shadowPath, Colors.black.withOpacity(0.5), 10.0, true);

    // Main Body
    Path path = Path();
    path.moveTo(0, 20); // Start from top-left (slightly down for curve)
    path.quadraticBezierTo(size.width * 0.20, 0, size.width * 0.35, 0);
    path.quadraticBezierTo(size.width * 0.40, 0, size.width * 0.40, 20);
    path.arcToPoint(Offset(size.width * 0.60, 20),
        radius: const Radius.circular(20.0), clockwise: false);
    path.quadraticBezierTo(size.width * 0.60, 0, size.width * 0.65, 0);
    path.quadraticBezierTo(size.width * 0.80, 0, size.width, 20);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();

    // Backdrop filter (Glass effect - simulated by painter color for now, 
    // real glass effect usually needs a widget stack outside painter)
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
