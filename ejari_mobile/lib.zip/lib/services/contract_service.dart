import 'package:intl/intl.dart';

class ContractService {
  static String generateContract({
    required String tenantName,
    required String tenantId,
    required String ownerName,
    required String propertyTitle,
    required String propertyAddress,
    required double price,
    required DateTime startDate,
    required DateTime endDate,
  }) {
    final dateFormat = DateFormat('yyyy/MM/dd');
    final startStr = dateFormat.format(startDate);
    final endStr = dateFormat.format(endDate);
    final today = dateFormat.format(DateTime.now());

    return '''
عقد إيجار إلكتروني موثق
رقم العقد: ${DateTime.now().millisecondsSinceEpoch}
تاريخ التحريـر: $today

أولاً: أطراف العقد
1. الطرف الأول (المؤجر): $ownerName
2. الطرف الثاني (المستأجر): $tenantName - هوية رقم: $tenantId

ثانياً: موضوع العقد
أجر الطرف الأول للطرف الثاني القابل لذلك:
الوحدة: $propertyTitle
العنوان: $propertyAddress

ثالثاً: مدة الإيجار
تبدأ من تاريخ: $startStr
وتنتهي في تاريخ: $endStr

رابعاً: القيمة الكيوة
اتفق الطرفان على أن تكون القيمة الكيوة الإجمالية مبلغ وقدره $price ج.م.
تم دفعها بالكامل عبر منصة "كيو".

خامساً: التزامات الأطراف
1. يلتزم المستأجر بالمحافظة على العين المؤجرة واستخدامها في الغرض المخصص لها.
2. يلتزم المؤجر بتسليم العين المؤجرة في التاريخ المحدد وبحالة صالحة للاستخدام.
3. منصة "كيو" هي الضامن المالي للعملية وتحتفظ بالمبلغ لحين استلام الوحدة.

سادساً: أحكام عامة
يخضع هذا العقد لقوانين الدولة، ويعتبر التوقيع الإلكتروني أدناه ملزماً للطرفين قانونياً.

----------------------------------------
توقيع الطرف الأول (المؤجر):                  توقيع الطرف الثاني (المستأجر):
[بانتظار التوقيع]                            [بانتظار التوقيع]
''';
  }
}
