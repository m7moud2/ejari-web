import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'theme/app_theme.dart';
import 'screens/onboarding_screen.dart';
import 'l10n/app_localizations.dart';
import 'services/firebase_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/home_screen.dart';
import 'screens/owner_home_screen.dart';
import 'screens/admin_home_screen.dart';
import 'services/auth_service.dart';

import 'screens/splash_screen.dart';

// Global Notifiers
final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.system);
final ValueNotifier<Locale> localeNotifier = ValueNotifier(const Locale('ar', 'SA'));

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Safe Firebase Initialization
  await FirebaseService.initialize();
  
  // Legacy Demo Auth Setup
  await AuthService.initDemoAccounts();

  // Load Saved Language Preference
  try {
    final prefs = await SharedPreferences.getInstance();
    final savedLang = prefs.getString('language_code');
    if (savedLang != null && (savedLang == 'ar' || savedLang == 'en')) {
      final countryCode = savedLang == 'ar' ? 'SA' : 'US';
      localeNotifier.value = Locale(savedLang, countryCode);
    }
  } catch (e) {
    debugPrint('Error loading language: $e');
  }
  
  runApp(
    MultiProvider(
      providers: [
        // Placeholder for future UserProvider, CartProvider, etc.
        Provider<String>(create: (_) => 'Keyo State Root'),
      ],
      child: const KeyoApp(),
    ),
  );
}

class KeyoApp extends StatefulWidget {
  const KeyoApp({super.key});

  @override
  State<KeyoApp> createState() => _KeyoAppState();
}

class _KeyoAppState extends State<KeyoApp> {
  Widget _startScreen = const SplashScreen();

  @override
  void initState() {
    super.initState();
    _checkSession();
  }

  Future<void> _checkSession() async {
    setState(() => _startScreen = const SplashScreen());
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, currentMode, _) {
        return ValueListenableBuilder<Locale>(
          valueListenable: localeNotifier,
          builder: (context, currentLocale, _) {
            return MaterialApp(
              title: 'كيو',
              debugShowCheckedModeBanner: false,
              theme: AppTheme.lightTheme,
              darkTheme: AppTheme.darkTheme,
              themeMode: currentMode,
              locale: currentLocale,
              localizationsDelegates: const [
                AppLocalizations.delegate, // <-- Custom Translation Engine
                GlobalMaterialLocalizations.delegate,
                GlobalWidgetsLocalizations.delegate,
                GlobalCupertinoLocalizations.delegate,
              ],
              supportedLocales: const [
                Locale('ar', 'SA'),
                Locale('en', 'US'),
              ],
              builder: (context, child) {
                return MediaQuery(
                  data: MediaQuery.of(context).copyWith(
                    textScaler: const TextScaler.linear(1.0),
                  ),
                  child: child!,
                );
              },
              home: _startScreen,
            );
      },
    );
  },
);
  }
}
