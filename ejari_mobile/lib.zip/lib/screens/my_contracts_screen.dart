import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/auth_service.dart';
import '../services/data_service.dart';
import 'contract_screen.dart';

class MyContractsScreen extends StatefulWidget {
  const MyContractsScreen({super.key});

  @override
  State<MyContractsScreen> createState() => _MyContractsScreenState();
}

class _MyContractsScreenState extends State<MyContractsScreen> {
  List<Map<String, dynamic>> _contracts = [];
  bool _isLoading = true;
  String? _userType;

  @override
  void initState() {
    super.initState();
    _loadContracts();
  }

  Future<void> _loadContracts() async {
    final user = await AuthService.getCurrentUser();
    setState(() {
      _userType = user?['type'] ?? 'tenant';
    });

    try {
      final bookings = await DataService.getBookings();
      final paidBookings = bookings.where((b) => b['status'] == 'paid' || b['status'] == 'active').toList();
      if (paidBookings.isNotEmpty) {
        final List<Map<String, dynamic>> realContracts = paidBookings.map((b) {
          String displayId = b['contractNumber'] ?? '';
          if (displayId.isEmpty && b['id'] != null) {
            String cleanId = b['id'].toString();
            displayId = 'CTR-${cleanId.length > 5 ? cleanId.substring(cleanId.length - 5) : cleanId}';
          } else if (displayId.isEmpty) {
            displayId = 'CTR-001';
          }
          
          return {
            'id': displayId,
            'propertyTitle': b['title'] ?? 'شقة سكنية إيليت',
            'ownerName': b['ownerName'] ?? 'أحمد محمد',
            'tenantName': b['tenantName'] ?? user?['name'] ?? 'محمود عبد القوي',
            'price': b['price']?.toString() ?? '0',
            'startDate': b['startDate']?.toString().isNotEmpty == true 
                ? b['startDate'].toString().substring(0, 10) 
                : '2026-06-06',
            'endDate': b['endDate']?.toString().isNotEmpty == true 
                ? b['endDate'].toString().substring(0, 10) 
                : '2027-06-06',
            'duration': 'سنة واحدة',
            'status': 'active',
            'signedByOwner': true,
            'signedByTenant': true,
            'createdAt': b['requestDate']?.toString().isNotEmpty == true 
                ? b['requestDate'].toString().substring(0, 10) 
                : '2026-06-06',
            'address': b['location'] ?? 'كيو، مصر',
            'deposit': b['price']?.toString() ?? '0',
          };
        }).toList();

        setState(() {
          _contracts = realContracts;
          _isLoading = false;
        });
        return;
      }
    } catch (e) {
      debugPrint('Error loading contracts from bookings: $e');
    }

    // Demo data fallback
    await Future.delayed(const Duration(milliseconds: 500));
    
    setState(() {
      _contracts = [
        {
          'id': 'CTR-001',
          'propertyTitle': 'شقة المعادي الفاخرة',
          'ownerName': 'أحمد محمد',
          'tenantName': 'محمود عبد القوي',
          'price': '5,000',
          'startDate': '2023-12-01',
          'endDate': '2024-12-01',
          'duration': 'سنة واحدة',
          'status': 'active', // active, pending, expired
          'signedByOwner': true,
          'signedByTenant': true,
          'createdAt': '2023-11-25',
          'address': 'شارع 9، المعادي، القاهرة',
          'deposit': '5,000',
        },
        {
          'id': 'CTR-002',
          'propertyTitle': 'فيلا الشيخ زايد',
          'ownerName': 'سارة أحمد',
          'tenantName': 'محمود عبد القوي',
          'price': '12,000',
          'startDate': '2024-01-01',
          'endDate': '2024-07-01',
          'duration': '6 أشهر',
          'status': 'pending',
          'signedByOwner': true,
          'signedByTenant': false,
          'createdAt': '2023-12-20',
          'address': 'الحي السابع، الشيخ زايد، الجيزة',
          'deposit': '12,000',
        },
        {
          'id': 'CTR-003',
          'propertyTitle': 'شقة مدينة نصر',
          'ownerName': 'خالد حسن',
          'tenantName': 'محمود عبد القوي',
          'price': '4,500',
          'startDate': '2022-06-01',
          'endDate': '2023-06-01',
          'duration': 'سنة واحدة',
          'status': 'expired',
          'signedByOwner': true,
          'signedByTenant': true,
          'createdAt': '2022-05-20',
          'address': 'شارع مصطفى النحاس، مدينة نصر، القاهرة',
          'deposit': '4,500',
        },
      ];
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('عقودي الإلكترونية'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: _showFilterDialog,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _contracts.isEmpty
              ? _buildEmptyState()
              : RefreshIndicator(
                  onRefresh: _loadContracts,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _contracts.length,
                    itemBuilder: (context, index) => _buildContractCard(_contracts[index]),
                  ),
                ),
    );
  }

  Widget _buildContractCard(Map<String, dynamic> contract) {
    final status = contract['status'];
    Color statusColor;
    String statusText;
    IconData statusIcon;

    switch (status) {
      case 'active':
        statusColor = Colors.green;
        statusText = 'ساري';
        statusIcon = Icons.check_circle;
        break;
      case 'pending':
        statusColor = Colors.orange;
        statusText = 'قيد التوقيع';
        statusIcon = Icons.pending;
        break;
      case 'expired':
        statusColor = Colors.grey;
        statusText = 'منتهي';
        statusIcon = Icons.history;
        break;
      default:
        statusColor = Colors.grey;
        statusText = 'غير معروف';
        statusIcon = Icons.help_outline;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color ?? Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: statusColor.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(statusIcon, color: statusColor, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      statusText,
                      style: TextStyle(
                        color: statusColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Text(
                  contract['id'],
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),

          // Content
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  contract['propertyTitle'],
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).textTheme.titleLarge?.color ?? AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 12),
                _buildInfoRow(Icons.location_on, contract['address']),
                const Divider(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('المالك', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Text(
                                contract['ownerName'],
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).textTheme.bodyLarge?.color ?? AppTheme.textPrimary,
                                ),
                              ),
                              if (contract['signedByOwner'])
                                const Padding(
                                  padding: EdgeInsets.only(right: 4),
                                  child: Icon(Icons.verified, color: Colors.green, size: 16),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('المستأجر', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Text(
                                contract['tenantName'],
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).textTheme.bodyLarge?.color ?? AppTheme.textPrimary,
                                ),
                              ),
                              if (contract['signedByTenant'])
                                const Padding(
                                  padding: EdgeInsets.only(right: 4),
                                  child: Icon(Icons.verified, color: Colors.green, size: 16),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Theme.of(context).brightness == Brightness.light ? Colors.grey[100] : const Color(0xFF334155),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('القيمة الشهرية', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                          Text('${contract['price']} ج.م', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppTheme.primaryColor)),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('المدة', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                          Text(
                            contract['duration'],
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).brightness == Brightness.light ? Colors.black87 : Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    const Icon(Icons.calendar_today, size: 14, color: AppTheme.textSecondary),
                    const SizedBox(width: 4),
                    Text(
                      'من ${contract['startDate']} إلى ${contract['endDate']}',
                      style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ContractScreen(
                            contractId: contract['id'],
                            propertyTitle: contract['propertyTitle'],
                            ownerName: contract['ownerName'],
                            tenantName: contract['tenantName'],
                            price: contract['price'],
                            startDate: contract['startDate'],
                            duration: contract['duration'],
                            address: contract['address'],
                            deposit: contract['deposit'],
                            signedByOwner: contract['signedByOwner'],
                            signedByTenant: contract['signedByTenant'],
                            isOwner: _userType == 'owner',
                          ),
                        ),
                      );
                    },
                    icon: const Icon(Icons.visibility),
                    label: const Text('عرض العقد'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 16, color: AppTheme.textSecondary),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: AppTheme.textSecondary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.description_outlined, size: 80, color: Colors.grey[300]),
          const SizedBox(height: 16),
          const Text(
            'لا توجد عقود',
            style: TextStyle(fontSize: 18, color: AppTheme.textSecondary),
          ),
        ],
      ),
    );
  }

  void _showFilterDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تصفية العقود'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('الكل'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              title: const Text('العقود السارية'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              title: const Text('قيد التوقيع'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              title: const Text('المنتهية'),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }
}
