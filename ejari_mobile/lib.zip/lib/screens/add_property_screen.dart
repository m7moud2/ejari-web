import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/data_service.dart';
import '../services/auth_service.dart';
import '../utils/image_utils.dart';
import '../widgets/elite_image.dart';
import 'listing_plans_screen.dart';
import 'package:image_picker/image_picker.dart';

class AddPropertyScreen extends StatefulWidget {
  final Map<String, dynamic>? initialData;
  const AddPropertyScreen({super.key, this.initialData});

  @override
  State<AddPropertyScreen> createState() => _AddPropertyScreenState();
}

class _AddPropertyScreenState extends State<AddPropertyScreen> {
  final PageController _pageController = PageController();
  int _currentStep = 0;
  final int _totalSteps = 4; // 0 to 4 (5 steps)

  @override
  void initState() {
    super.initState();
    if (widget.initialData != null) {
      _titleController.text = widget.initialData!['title'] ?? '';
      _priceController.text = widget.initialData!['price']?.toString() ?? '';
      _locationController.text = widget.initialData!['location'] ?? '';
      _areaController.text = widget.initialData!['area']?.toString() ?? '';
      _bedsController.text = widget.initialData!['beds']?.toString() ?? '';
      _bathsController.text = widget.initialData!['baths']?.toString() ?? '';
      _selectedImage = widget.initialData!['image'];
      _isLocalFile = _selectedImage != null && !_selectedImage!.startsWith('assets/');
      _selectedPlan = widget.initialData!['listingMode'];
      _hasReel = widget.initialData!['hasReel'] ?? false;
      
      // If editing, we skip to the last step or allow full edit
      // For UX, we'll start at step 0 but pre-filled
    }
  }

  // Form Controllers
  final _titleController = TextEditingController();
  final _priceController = TextEditingController();
  final _locationController = TextEditingController();
  final _areaController = TextEditingController();
  final _bedsController = TextEditingController();
  final _bathsController = TextEditingController();
  
  String? _selectedImage;
  bool _isLocalFile = false;
  String? _selectedPlan;
  bool _isLoading = false;
  bool _hasReel = false;
  String _propertyType = 'rent'; // 'rent' or 'sale'

  @override
  void dispose() {
    _pageController.dispose();
    _titleController.dispose();
    _priceController.dispose();
    _locationController.dispose();
    _areaController.dispose();
    _bedsController.dispose();
    _bathsController.dispose();
    super.dispose();
  }

  bool _validateStep() {
    switch (_currentStep) {
      case 0:
        if (_titleController.text.isEmpty || _locationController.text.isEmpty || _priceController.text.isEmpty) {
          _showError('برجاء إكمال البيانات الأساسية');
          return false;
        }
        break;
      case 1:
        if (_areaController.text.isEmpty || _bedsController.text.isEmpty || _bathsController.text.isEmpty) {
          _showError('برجاء إدخال المساحة وعدد الغرف');
          return false;
        }
        break;
      case 2:
        if (_selectedImage == null) {
          _showError('برجاء إضافة صورة حقيقية للعقار أولاً');
          return false;
        }
        break;
      case 4:
        if (_selectedPlan == null) {
          _showError('برجاء اختيار باقة النشر لإرسال الطلب');
          return false;
        }
        break;
    }
    return true;
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.red),
    );
  }

  void _nextStep() {
    if (!_validateStep()) return;

    if (_currentStep < _totalSteps) {
      _pageController.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
    } else {
      _submitProperty();
    }
  }

  void _previousStep() {
    if (_currentStep > 0) {
      _pageController.previousPage(duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
    }
  }

  void _choosePlan() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const ListingPlansScreen(isFromWizard: true)),
    );
    if (result != null) {
      setState(() => _selectedPlan = result);
    }
  }

  Future<void> _submitProperty() async {
    if (_selectedPlan == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('برجاء اختيار باقة أو نظام العمولة أولاً')),
      );
      return;
    }

    setState(() => _isLoading = true);
    final propertyData = {
      'title': _titleController.text,
      'price': _priceController.text,
      'location': _locationController.text,
      'area': _areaController.text,
      'beds': _bedsController.text,
      'baths': _bathsController.text,
      'image': _selectedImage!, // Guaranteed by validation
      'hasReel': _hasReel,
      'listingMode': _selectedPlan,
      'status': 'pending', // Explicitly set for UI clarity
      'type': _propertyType,
    };

    final user = await AuthService.getCurrentUser();
    propertyData['ownerId'] = user?['email'] ?? 'unknown';
    await DataService.addProperty(propertyData);

    setState(() => _isLoading = false);
    if (mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('تم إرسال طلبك بنجاح! 🚀'),
          content: const Text(
            'طلبك الآن قيد المراجعة من قبل إدارة كيو إيليت. سيتم فحص البيانات والصور، وسيصلك إشعار فور الموافقة على النشر.'
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // close dialog
                Navigator.pop(context); // back to profile/home
              },
              child: const Text('حسناً'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: const Text('إدراج عقار حصري ✨'),
        leading: IconButton(
          icon: const Icon(Icons.close_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          _buildStepIndicator(),
          Expanded(
            child: PageView(
              controller: _pageController,
              physics: const NeverScrollableScrollPhysics(),
              onPageChanged: (int page) => setState(() => _currentStep = page),
              children: [
                _buildStep1(),
                _buildStep2(),
                _buildStep3(),
                _buildStep4(),
                _buildStep5(),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomAction(),
    );
  }

  Widget _buildStepIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 30),
      child: Row(
        children: List.generate(5, (index) {
          bool isActive = index <= _currentStep;
          return Expanded(
            child: Row(
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: isActive ? AppTheme.primaryColor : Colors.grey[300],
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      '${index + 1}',
                      style: TextStyle(color: isActive ? Colors.white : Colors.grey[600], fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                if (index < 4)
                  Expanded(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      height: 2,
                      color: index < _currentStep ? AppTheme.primaryColor : Colors.grey[300],
                    ),
                  ),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildStep1() {
    return _buildStepContainer(
      title: 'المعلومات الأساسية',
      description: 'أدخل تفاصيل العنوان والسعر لعقارك الجديد.',
      child: Column(
        children: [
          _buildTextField(_titleController, 'عنوان الإعلان', Icons.title_rounded, 'مثال: شقة مودرن بمدينتي'),
          const SizedBox(height: 20),
          _buildTextField(_locationController, 'الموقع بالتفصيل', Icons.location_on_rounded, 'الحي، الشارع، المعلم المميز'),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _buildPropertyTypeOption('إيجار', 'rent', Icons.key_rounded),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildPropertyTypeOption('تمليك', 'sale', Icons.real_estate_agent_rounded),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _buildTextField(_priceController, _propertyType == 'rent' ? 'الإيجار الشهري المطلوب' : 'سعر البيع المطلوب', Icons.payments_rounded, '0.00', isNumber: true),
        ],
      ),
    );
  }

  Widget _buildStep2() {
    return _buildStepContainer(
      title: 'المواصفات الفنية',
      description: 'ساعد المستأجرين في معرفة حجم ومرافق العقار.',
      child: Column(
        children: [
          _buildTextField(_areaController, 'المساحة الكلية (م²)', Icons.straighten_rounded, '0', isNumber: true),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: _buildTextField(_bedsController, 'غرف النوم', Icons.king_bed_rounded, '0', isNumber: true)),
              const SizedBox(width: 16),
              Expanded(child: _buildTextField(_bathsController, 'الحمامات', Icons.bathtub_rounded, '0', isNumber: true)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStep3() {
    return _buildStepContainer(
      title: 'الصور والوسائط',
      description: 'العقارات التي تحتوي على صور احترافية تؤجر أسرع بـ 3 أضعاف.',
      child: Column(
        children: [
          GestureDetector(
            onTap: _showImagePicker,
            child: Container(
              height: 250,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppTheme.primaryColor.withOpacity(0.1)),
                image: _selectedImage != null 
                    ? EliteImage.decoration(
                        path: _selectedImage!,
                        isLocalFile: _isLocalFile,
                      )
                    : null,
              ),
              child: _selectedImage == null ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_a_photo_rounded, size: 50, color: AppTheme.primaryColor.withOpacity(0.5)),
                  const SizedBox(height: 12),
                  const Text('اضغط لإضافة صور عالية الجودة', style: TextStyle(color: AppTheme.textSecondary)),
                ],
              ) : null,
            ),
          ),
          const SizedBox(height: 20),
          _buildVirtualTourSection(),
          const SizedBox(height: 20),
          _buildReelUploadSection(),
        ],
      ),
    );
  }

  Widget _buildStep4() {
    return _buildStepContainer(
      title: 'المميزات والمرافق',
      description: 'اختر المميزات الإضافية المتاحة في العقار.',
      child: Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          _buildAmenityChip('تكييف', Icons.ac_unit),
          _buildAmenityChip('أثاث كامل', Icons.chair_rounded),
          _buildAmenityChip('أمن 24/7', Icons.security),
          _buildAmenityChip('موقف سيارات', Icons.local_parking),
          _buildAmenityChip('إنترنت سريع', Icons.wifi),
          _buildAmenityChip('حمام سباحة', Icons.pool),
        ],
      ),
    );
  }

  Widget _buildStep5() {
    return _buildStepContainer(
      title: 'مراجعة ونشر',
      description: 'اختر نظام النشر المفضل لمتابعة الإعلان.',
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
            child: Column(
              children: [
                _buildReviewRow('العنوان', _titleController.text),
                _buildReviewRow('السعر', '${_priceController.text} ج.م'),
                _buildReviewRow('الموقع', _locationController.text),
              ],
            ),
          ),
          const SizedBox(height: 32),
          GestureDetector(
            onTap: _choosePlan,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: _selectedPlan == null ? AppTheme.accentColor.withOpacity(0.1) : Colors.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _selectedPlan == null ? AppTheme.accentColor : Colors.green, width: 2),
              ),
              child: Row(
                children: [
                  Icon(
                    _selectedPlan == null ? Icons.workspace_premium_rounded : Icons.check_circle_rounded,
                    color: _selectedPlan == null ? AppTheme.accentColor : Colors.green,
                    size: 32,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _selectedPlan == null ? 'اختار نظام النشر' : 'النظام المختار:',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text(
                          _selectedPlan == null 
                              ? 'باقات إيليت أو نظام العمولة' 
                              : (_selectedPlan == 'commission' ? 'نظام العمولة (0 ج.م مقدماً)' : 'باقة ${_selectedPlan!.toUpperCase()}'),
                          style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: AppTheme.textSecondary),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepContainer({required String title, required String description, required Widget child}) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(description, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 14)),
          const SizedBox(height: 40),
          child,
        ],
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, String hint, {bool isNumber = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 10),
        TextField(
          controller: controller,
          keyboardType: isNumber ? TextInputType.number : TextInputType.text,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: Icon(icon, color: AppTheme.primaryColor),
          ),
        ),
      ],
    );
  }

  Widget _buildPropertyTypeOption(String title, String value, IconData icon) {
    bool isSelected = _propertyType == value;
    return GestureDetector(
      onTap: () => setState(() => _propertyType = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryColor : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isSelected ? AppTheme.primaryColor : Colors.grey[300]!),
        ),
        child: Column(
          children: [
            Icon(icon, color: isSelected ? Colors.white : AppTheme.textSecondary, size: 28),
            const SizedBox(height: 8),
            Text(title, style: TextStyle(color: isSelected ? Colors.white : AppTheme.textSecondary, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildAmenityChip(String label, IconData icon) {
    return FilterChip(
      label: Text(label),
      avatar: Icon(icon, size: 18),
      onSelected: (v) {},
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    );
  }

  Widget _buildReviewRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppTheme.textSecondary)),
          Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.bold), textAlign: TextAlign.end, maxLines: 1, overflow: TextOverflow.ellipsis)),
        ],
      ),
    );
  }

  Widget _buildBottomAction() {
    return Container(
      padding: const EdgeInsets.all(30),
      color: Colors.white,
      child: Row(
        children: [
          if (_currentStep > 0)
            OutlinedButton(
              onPressed: _previousStep,
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.all(20),
                shape: const CircleBorder(),
                side: const BorderSide(color: AppTheme.primaryColor),
              ),
              child: const Icon(Icons.arrow_back_rounded, color: AppTheme.primaryColor),
            ),
          const SizedBox(width: 16),
          Expanded(
            child: ElevatedButton(
              onPressed: _isLoading ? null : _nextStep,
              child: _isLoading 
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : Text(_currentStep == _totalSteps ? 'نشر العقار الآن' : 'الخطوة التالية'),
            ),
          ),
        ],
      ),
    );
  }

  void _showImagePicker() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('رفع صورة العقار', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Text('سيتم ضغط الصورة تلقائياً لتوفير المساحة', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
            const SizedBox(height: 24),
            ListTile(
              leading: const Icon(Icons.photo_library_rounded, color: AppTheme.primaryColor),
              title: const Text('اختيار من المعرض'),
              onTap: () => _pickImage(ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt_rounded, color: AppTheme.primaryColor),
              title: const Text('التقاط صورة الآن'),
              onTap: () => _pickImage(ImageSource.camera),
            ),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    Navigator.pop(context);
    final xFile = await ImageUtils.pickAndCompress(source: source);
    if (xFile != null) {
      setState(() {
        _selectedImage = xFile.path;
        _isLocalFile = true;
      });
    }
  }

  Widget _buildVirtualTourSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF2C3E50), Color(0xFF4CA1AF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          const Icon(Icons.vrpano, color: Colors.white, size: 30),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('جولة افتراضية 360°', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                Text('سيتم عرضها بنظام VR', style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
          Switch(value: false, onChanged: (v) {}, activeColor: Colors.white),
        ],
      ),
    );
  }

  Widget _buildReelUploadSection() {
    return GestureDetector(
      onTap: () {
        showModalBottomSheet(
          context: context,
          backgroundColor: Colors.transparent,
          builder: (context) => Container(
            decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.video_library_rounded, size: 50, color: AppTheme.primaryColor),
                const SizedBox(height: 16),
                const Text('اختيار المقطع المرئي (Reel)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('اختر فيديو قصير ومميز لعقارك ليتم عرضه في قسم الريلز للمستثمرين.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 24),
                ListTile(
                  leading: const Icon(Icons.photo_camera_back_rounded, color: Colors.blue),
                  title: const Text('اختيار من المعرض'),
                  onTap: () {
                    setState(() => _hasReel = true);
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرفاق الفيديو بنجاح 📹'), backgroundColor: Colors.green));
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.videocam_rounded, color: Colors.red),
                  title: const Text('تصوير فيديو الآن 🔴'),
                  onTap: () {
                    setState(() => _hasReel = true);
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرفاق الفيديو بنجاح 📹'), backgroundColor: Colors.green));
                  },
                ),
              ],
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _hasReel ? Colors.black87 : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _hasReel ? Colors.black : AppTheme.primaryColor.withOpacity(0.3), width: 2),
          boxShadow: [if (!_hasReel) BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10)],
        ),
        child: Row(
          children: [
            Icon(Icons.video_camera_front_rounded, color: _hasReel ? Colors.white : AppTheme.primaryColor, size: 30),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_hasReel ? 'تم ربط ريلز مخصص 📹' : 'إدراج كفيديو Reel', style: TextStyle(color: _hasReel ? Colors.white : Colors.black, fontSize: 16, fontWeight: FontWeight.bold)),
                  Text(_hasReel ? 'سيتم النشر في نافذة الريلز بشكل تلقائي' : 'جذب مضاعف لعملائك عبر تجربة فيديو تيك توك', style: TextStyle(color: _hasReel ? Colors.white70 : AppTheme.textSecondary, fontSize: 11)),
                ],
              ),
            ),
            Icon(_hasReel ? Icons.check_circle_rounded : Icons.add_circle_outline_rounded, color: _hasReel ? Colors.greenAccent : AppTheme.primaryColor),
          ],
        ),
      ),
    );
  }
}
