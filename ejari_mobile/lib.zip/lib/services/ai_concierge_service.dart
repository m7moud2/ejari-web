import 'dart:convert';
import 'package:http/http.dart' as http;
import '../services/data_service.dart';

/// خدمة الذكاء الاصطناعي لمساعد كونسيرج كيو إيليت
/// ترسل رسائل المستخدم لخادم Express الذي يستدعي Gemini API ويُعيد الردود والعقارات المقترحة
class AiConciergeService {
  /// عنوان الـ API الخلفية — يُكيَّف تلقائياً للمحاكي والمتصفح
  static String get _baseUrl {
    // على محاكي الأندرويد، localhost = 10.0.2.2
    // على المتصفح/iOS Simulator أو الجهاز الحقيقي = localhost
    const bool isAndroidEmulator = bool.fromEnvironment('ANDROID_EMULATOR', defaultValue: false);
    if (isAndroidEmulator) {
      return 'http://10.0.2.2:5050/api';
    }
    // للويب (flutter run -d chrome) و iOS Simulator
    return 'http://localhost:5050/api';
  }

  /// إرسال رسالة للـ API الخلفية واسترجاع الرد والعقارات المقترحة
  /// يعود بـ Map يحتوي على:
  ///   - 'reply': String — نص رد المساعد الذكي
  ///   - 'properties': List<Map> — العقارات المقترحة من قاعدة البيانات
  static Future<Map<String, dynamic>> getChatResponse(String userMessage) async {
    try {
      final uri = Uri.parse('$_baseUrl/ai/chat');
      final response = await http.post(
        uri,
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({'message': userMessage}),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final decoded = jsonDecode(utf8.decode(response.bodyBytes));
        if (decoded['success'] == true) {
          final data = decoded['data'] as Map<String, dynamic>;
          final List<dynamic> rawProps = data['matchedProperties'] ?? [];
          final List<Map<String, dynamic>> properties = rawProps
              .map((p) => _normalizeProperty(p as Map<String, dynamic>))
              .toList();

          return {
            'reply': data['reply'] ?? 'أهلاً بك في كيو كونسيرج 🔑',
            'properties': properties,
          };
        }
      }
      // إذا جاء رد غير ناجح من السيرفر
      throw Exception('Server returned error: ${response.statusCode}');

    } catch (e) {
      // 🔄 الـ Fallback المحلي — يُفعَّل عند انقطاع الاتصال بالخادم
      return await _localFallback(userMessage);
    }
  }

  /// تحويل بيانات العقار القادمة من MongoDB إلى الهيكل المتوقع في واجهة Flutter
  static Map<String, dynamic> _normalizeProperty(Map<String, dynamic> p) {
    final features = p['features'] as Map<String, dynamic>? ?? {};
    return {
      'id': p['_id']?.toString() ?? p['id']?.toString() ?? '',
      'title': p['title'] ?? '',
      'price': (p['price'] ?? 0).toString(),
      'location': (p['location'] as Map<String, dynamic>?)?['address'] ?? '',
      'image': (p['images'] as List<dynamic>?)?.isNotEmpty == true
          ? (p['images'] as List<dynamic>)[0].toString()
          : 'assets/images/home1.jpg',
      'beds': (features['bedrooms'] ?? 0).toString(),
      'baths': (features['bathrooms'] ?? 0).toString(),
      'area': (features['area'] ?? 0).toString(),
      'type': p['type'] ?? 'apartment',
      'status': p['status'] ?? 'available',
      'amenities': p['amenities'] ?? [],
      'furnished': features['furnished'] ?? false,
      'rating': '4.8',
    };
  }

  /// نظام السقوط الآمن المحلي — يعمل عند تعذّر الاتصال بالخادم
  static Future<Map<String, dynamic>> _localFallback(String query) async {
    await Future.delayed(const Duration(milliseconds: 800));

    final all = await DataService.getAllProperties();
    final q = query.toLowerCase();

    List<Map<String, dynamic>> filtered;

    if (_containsAny(q, ['رخيص', 'اقتصادي', 'cheap', 'بسيط'])) {
      filtered = all.where((p) {
        final price = _parsePrice(p['price']);
        return price <= 5000;
      }).toList();
    } else if (_containsAny(q, ['فاخر', 'luxury', 'بريميم', 'نخبة'])) {
      filtered = all.where((p) {
        final price = _parsePrice(p['price']);
        return price >= 8000 || (p['type'] ?? '').contains('فلل');
      }).toList();
    } else if (_containsAny(q, ['شقة', 'شقق', 'apartment'])) {
      filtered = all.where((p) => (p['type'] ?? '').contains('شقق') || p['type'] == 'apartment').toList();
    } else if (_containsAny(q, ['فيلا', 'فلل', 'villa', 'منزل'])) {
      filtered = all.where((p) => (p['type'] ?? '').contains('فلل') || p['type'] == 'villa').toList();
    } else if (_containsAny(q, ['مكتب', 'office', 'تجاري'])) {
      filtered = all.where((p) => (p['type'] ?? '').contains('مكاتب') || p['type'] == 'office').toList();
    } else {
      filtered = all.where((p) {
        return (p['title'] ?? '').toString().contains(query) ||
            (p['location'] ?? '').toString().contains(query);
      }).toList();
    }

    final results = filtered.take(4).toList();

    String reply;
    if (results.isNotEmpty) {
      reply = 'أهلاً يا فندم! 🔑 وجدت لك ${results.length} عقار يناسب طلبك. (ملاحظة: النتائج من البيانات المحلية)';
    } else {
      reply = 'عذراً يا فندم، لم أجد عقارات تطابق "$query" حالياً. يمكنني مساعدتك في البحث بمعايير مختلفة أو التواصل مع مستشار كيو إيليت. 🔑';
    }

    return {'reply': reply, 'properties': results};
  }

  static int _parsePrice(dynamic price) {
    if (price == null) return 0;
    return int.tryParse(price.toString().replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
  }

  static bool _containsAny(String text, List<String> keywords) {
    return keywords.any((k) => text.contains(k.toLowerCase()));
  }
}
