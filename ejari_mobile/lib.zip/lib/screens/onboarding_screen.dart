import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<Map<String, dynamic>> _pages = [
    {
      'title': 'مرحباً في إيليت',
      'body': 'بوابتك الحصرية نحو أرقى وأفخم المساكن ومقرات الأعمال المصممة لصفوة المجتمع.',
      'icon': Icons.diamond_outlined,
    },
    {
      'title': 'أمان بلا حدود',
      'body': 'توثيق إلكتروني لعقود الإيجار، ومعاملات مالية مشفرة بضمان منصتنا لحفظ حقوقك كاملة.',
      'icon': Icons.security_rounded,
    },
    {
      'title': 'عناية فائقة',
      'body': 'لأن وقتك ثمين، نقدم صيانة فورية ونظافة فندقية لإدارة أملاكك بكل راحة وهدوء.',
      'icon': Icons.auto_awesome_rounded,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC), // Very light premium grey
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          TextButton(
            onPressed: () {
               Navigator.pushReplacement(
                context,
                PageRouteBuilder(
                  pageBuilder: (_, __, ___) => const LoginScreen(),
                  transitionsBuilder: (_, animation, __, child) => FadeTransition(opacity: animation, child: child),
                ),
              );
            },
            child: const Text('تخطي', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              onPageChanged: (index) => setState(() => _currentPage = index),
              physics: const BouncingScrollPhysics(),
              itemCount: _pages.length,
              itemBuilder: (context, index) {
                return SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Elegant Icon instead of heavy images
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 20, spreadRadius: 5)
                            ],
                          ),
                          child: Icon(
                            _pages[index]['icon'] as IconData,
                            size: 40,
                            color: const Color(0xFFBCA374),
                          ),
                        ),
                        const SizedBox(height: 40),
                        Text(
                          _pages[index]['title'] as String,
                          style: const TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                            color: const Color(0xFF1F2937),
                            letterSpacing: 1.2,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _pages[index]['body'] as String,
                          style: const TextStyle(
                            fontSize: 15,
                            height: 1.6,
                            color: Colors.blueGrey,
                            fontWeight: FontWeight.w400,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          
          // Custom Elegant Bottom Controls
          Padding(
            padding: const EdgeInsets.fromLTRB(40, 0, 40, 60),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Minimal Indicators
                Row(
                  children: List.generate(
                    _pages.length,
                    (index) => AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.only(right: 6),
                      height: 4,
                      width: _currentPage == index ? 24 : 4,
                      decoration: BoxDecoration(
                        color: _currentPage == index ? const Color(0xFFBCA374) : Colors.grey[300],
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                ),
                
                // Primary Action Button
                GestureDetector(
                  onTap: () {
                    if (_currentPage == _pages.length - 1) {
                      Navigator.pushReplacement(
                         context,
                         PageRouteBuilder(
                           pageBuilder: (_, __, ___) => const LoginScreen(),
                           transitionsBuilder: (_, animation, __, child) => FadeTransition(opacity: animation, child: child),
                         ),
                       );
                    } else {
                      _pageController.nextPage(
                        duration: const Duration(milliseconds: 500),
                        curve: Curves.easeInOutCubic,
                      );
                    }
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    padding: EdgeInsets.symmetric(horizontal: _currentPage == _pages.length - 1 ? 40 : 20, vertical: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFBCA374),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _currentPage == _pages.length - 1 ? 'ابدأ الرحلة' : '',
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        if (_currentPage != _pages.length - 1) 
                           const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white, size: 16)
                        else ...[
                           const SizedBox(width: 8),
                           const Icon(Icons.auto_awesome, color: AppTheme.accentColor, size: 16),
                        ]
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
