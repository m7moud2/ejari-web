import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'help_center_screen.dart';
import '../main.dart'; // Import to access themeNotifier
import 'package:local_auth/local_auth.dart'; // Add import
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _biometricsEnabled = true;
  bool _isDarkMode = false;
  String _language = 'ar';
  
  final LocalAuthentication auth = LocalAuthentication();

  @override
  void initState() {
    super.initState();
    // Sync local state with global notifier
    _isDarkMode = themeNotifier.value == ThemeMode.dark;
    _language = localeNotifier.value.languageCode;
    _loadBiometricState();
  }

  Future<void> _loadBiometricState() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _biometricsEnabled = prefs.getBool('biometric_enabled') ?? false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionHeader('الحسابات والتحويلات'),
          _buildListTile(
            title: 'تفاصيل استلام الأرباح',
            subtitle: '01069813210 - InstaPay',
            icon: Icons.account_balance_wallet_rounded,
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الحساب معتمد ومؤمن ✅')));
            },
          ),
          const Divider(height: 32),
          _buildSectionHeader('العامة'),
          _buildListTile(
            title: 'اللغة / Language',
            subtitle: _language == 'ar' ? 'العربية' : 'English',
            icon: Icons.language,
            trailing: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _language,
                items: const [
                  DropdownMenuItem(value: 'ar', child: Text('العربية')),
                  DropdownMenuItem(value: 'en', child: Text('English')),
                ],
                onChanged: (val) async {
                  if (val == null) return;
                  setState(() => _language = val);
                  final countryCode = val == 'ar' ? 'SA' : 'US';
                  localeNotifier.value = Locale(val, countryCode);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setString('language_code', val);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          val == 'ar'
                              ? 'تم تغيير اللغة إلى العربية'
                              : 'Language changed to English',
                        ),
                      ),
                    );
                  }
                },
              ),
            ),
          ),
          _buildSwitchTile(
            title: 'الوضع الليلي',
            subtitle: 'تفعيل المظهر الداكن',
            icon: Icons.dark_mode,
            value: _isDarkMode,
            onChanged: (val) {
               setState(() => _isDarkMode = val);
               // Update global theme
               themeNotifier.value = val ? ThemeMode.dark : ThemeMode.light;
            },
          ),
          const Divider(height: 32),
          
          _buildSectionHeader('الإشعارات والأمان'),
          _buildSwitchTile(
            title: 'الإشعارات',
            subtitle: 'تلقي تحديثات الحجز والعروض',
            icon: Icons.notifications,
            value: _notificationsEnabled,
            onChanged: (val) => setState(() => _notificationsEnabled = val),
          ),
           _buildSwitchTile(
            title: 'تفعيل البصمة',
            subtitle: 'تسجيل الدخول باستخدام الوجه/البصمة',
            icon: Icons.fingerprint,
            value: _biometricsEnabled,
            onChanged: (val) async {
              if (val) {
                // Try to authenticate before enabling
                bool authenticated = false;
                try {
                   final canCheck = await auth.canCheckBiometrics;
                   if (canCheck) {
                     authenticated = await auth.authenticate(
                        localizedReason: 'يرجى تأكيد هويتك لتفعيل الدخول بالبصمة',
                        options: const AuthenticationOptions(stickyAuth: true),
                     );
                   } else {
                     if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('جهازك لا يدعم البصمة أو غير مفعلة')),
                        );
                     }
                   }
                } catch (e) {
                   debugPrint('Biometric Error: $e');
                }

                if (authenticated) {
                   final prefs = await SharedPreferences.getInstance();
                   await prefs.setBool('biometric_enabled', true);
                   setState(() => _biometricsEnabled = true);
                   if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تم تفعيل الدخول بالبصمة بنجاح ✅')),
                      );
                   }
                }
              } else {
                final prefs = await SharedPreferences.getInstance();
                await prefs.setBool('biometric_enabled', false);
                setState(() => _biometricsEnabled = false);
              }
            },
          ),
          
          const Divider(height: 32),
          _buildSectionHeader('الدعم'),
            _buildListTile(
             title: 'مركز المساعدة',
             icon: Icons.help_outline,
             onTap: () {
               Navigator.push(context, MaterialPageRoute(builder: (context) => const HelpCenterScreen()));
             },
           ),
            _buildListTile(
             title: 'سياسة الخصوصية',
             icon: Icons.privacy_tip_outlined,
             onTap: () {
               showDialog(
                 context: context,
                 builder: (context) => AlertDialog(
                   title: const Text('سياسة الخصوصية'),
                   content: const Text('نحن نلتزم بحفظ بياناتك وخصوصيتك بأعلى معايير الأمان العالمية في كيو إيليت.'),
                   actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))],
                 ),
               );
             },
           ),
            _buildListTile(
             title: 'عن التطبيق',
             subtitle: 'نسخة 1.0.0 (Beta)',
             icon: Icons.info_outline,
             onTap: () {
               showAboutDialog(
                 context: context,
                 applicationName: 'Keyo Elite',
                 applicationVersion: '1.0.0',
                 applicationIcon: Image.asset('assets/images/app_icon.png', height: 50),
                 children: [const Text('نظام كيو إيليت هو الحل المتكامل لإدارة العقارات في مصر.')],
               );
             },
           ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        title,
        style: const TextStyle(
          color: AppTheme.primaryColor,
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget _buildListTile({
    required String title,
    String? subtitle,
    required IconData icon,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.grey[100],
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: Colors.black87),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: subtitle != null ? Text(subtitle) : null,
      trailing: trailing ?? (onTap != null ? const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey) : null),
      onTap: onTap,
    );
  }

  Widget _buildSwitchTile({
    required String title,
    String? subtitle,
    required IconData icon,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: value ? AppTheme.primaryColor.withOpacity(0.1) : Colors.grey[100],
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: value ? AppTheme.primaryColor : Colors.black87),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: subtitle != null ? Text(subtitle) : null,
      trailing: Switch(
        value: value,
        onChanged: onChanged,
        activeColor: AppTheme.primaryColor,
      ),
    );
  }
}
