import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class SubscriptionService {
  static const String _subscriptionKey = 'user_subscription';

  // Commission Rates
  static const double COMMISSION_RENT = 0.10; // 10% (one month)
  static const double COMMISSION_SALE = 0.025; // 2.5%

  // Owner Plans
  static const Map<String, Map<String, dynamic>> ownerPlans = {
    'free': {
      'name': 'مجاني',
      'price': 0,
      'properties_limit': 1,
      'requests_limit': 5,
      'commission': true, // Must pay commission if over limit
      'priority': false,
    },
    'bronze': {
      'name': 'برونزي',
      'price': 299,
      'properties_limit': 5,
      'commission': false, // No commission for package listings
      'priority': false,
      'support': false,
    },
    'silver': {
      'name': 'فضي',
      'price': 599,
      'properties_limit': 15,
      'commission': false,
      'priority': true,
      'reels': true, // Show in reels
    },
    'gold': {
      'name': 'ذهبي (Elite)',
      'price': 1299,
      'properties_limit': -1, // Unlimited
      'commission': false,
      'priority': true,
      'reels': true,
      'featured': true,
    },
  };

  // ... (rest of the code remains the same or slightly adjusted for matching)
  // Tenant Plans
  static const Map<String, Map<String, dynamic>> tenantPlans = {
    'free': {
      'name': 'مجاني',
      'price': 0,
      'bookings_limit': 3,
      'notifications': false,
    },
    'premium': {
      'name': 'بريميوم',
      'price': 199,
      'bookings_limit': -1,
      'notifications': true,
      'priority': true,
    },
  };

  // Get current subscription
  static Future<Map<String, dynamic>> getCurrentSubscription() async {
    final prefs = await SharedPreferences.getInstance();
    String? subJson = prefs.getString(_subscriptionKey);
    
    if (subJson != null) {
      return jsonDecode(subJson) as Map<String, dynamic>;
    }
    
    return {
      'plan': 'free',
      'type': 'owner', // Defaulting to owner for this flow
      'start_date': DateTime.now().toIso8601String(),
    };
  }

  // Subscribe to a plan
  static Future<void> subscribe(String planId, String userType) async {
    final prefs = await SharedPreferences.getInstance();
    Map<String, dynamic> subscription = {
      'plan': planId,
      'type': userType,
      'start_date': DateTime.now().toIso8601String(),
      'end_date': DateTime.now().add(const Duration(days: 30)).toIso8601String(),
    };
    await prefs.setString(_subscriptionKey, jsonEncode(subscription));
  }

  // Check if owner can list a property
  static Future<Map<String, dynamic>> checkListingAbility() async {
    final sub = await getCurrentSubscription();
    final plan = ownerPlans[sub['plan']]!;
    
    // In a real app, we'd query the DB for the current property count
    // For the demo, we'll assume the user has used 1 listing
    int currentCount = 1; 
    int limit = plan['properties_limit'];

    bool hasPackageRoom = (limit == -1 || currentCount < limit);

    return {
      'can_list_via_package': hasPackageRoom,
      'current_plan': plan['name'],
      'must_pay_commission': !hasPackageRoom,
      'commission_rate_rent': COMMISSION_RENT,
      'commission_rate_sale': COMMISSION_SALE,
    };
  }

  static Map<String, dynamic>? getPlanDetails(String planId, String userType) {
    return userType == 'owner' ? ownerPlans[planId] : tenantPlans[planId];
  }
}

