import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/data_service.dart';
import 'property_details_screen.dart';

class PropertyReelsScreen extends StatefulWidget {
  const PropertyReelsScreen({super.key});

  @override
  State<PropertyReelsScreen> createState() => _PropertyReelsScreenState();
}

class _PropertyReelsScreenState extends State<PropertyReelsScreen> {
  final PageController _pageController = PageController();
  List<Map<String, dynamic>> _reels = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadReels();
  }

  Future<void> _loadReels() async {
    // Simulated reels fetching
    final properties = await DataService.getAllProperties();
    // Simulate finding properties that have reels attached
    final reeledProperties = properties.where((p) => p['hasReel'] == true).toList();
    
    setState(() {
      // If no properties are explicitly marked with hasReel, let's just show all as simulation
      _reels = reeledProperties.isNotEmpty ? reeledProperties : properties;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: CircularProgressIndicator(color: Colors.white)),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: const SizedBox.shrink(), // hide default back button if in navigation bar
        title: const Text(
          'إيليت ريلز 💎',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 22, letterSpacing: 1.5),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.camera_alt_rounded, color: Colors.white),
            onPressed: () {
               ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الذهاب لإدراج عقار جديد...')));
            },
          ),
        ],
      ),
      body: PageView.builder(
        scrollDirection: Axis.vertical,
        controller: _pageController,
        itemCount: _reels.length,
        itemBuilder: (context, index) {
          final reel = _reels[index];
          return _buildReelPage(reel);
        },
      ),
    );
  }

  Widget _buildReelPage(Map<String, dynamic> reel) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // Background Image (Video Placeholder) with zoom animation feel
        AnimatedScale(
          scale: 1.05,
          duration: const Duration(seconds: 10),
          child: Image.asset(
            reel['image'] ?? 'assets/images/home1.jpg',
            fit: BoxFit.cover,
          ),
        ),
        
        // Dark Gradient Overlay for text readability
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.black.withOpacity(0.6), 
                Colors.transparent, 
                Colors.black.withOpacity(0.8)
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),

        // Play Icon Overlay to simulate it's a video
        const Center(
          child: Icon(Icons.play_circle_outline_rounded, color: Colors.white54, size: 80),
        ),

        // Property Info Overlay (Bottom Left)
        Positioned(
          bottom: 30, // Higher than bottom nav bar
          right: 20,
          left: 80, // Leave space for side actions
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppTheme.accentColor, width: 2),
                    ),
                    child: const CircleAvatar(
                      radius: 20,
                      backgroundImage: AssetImage('assets/images/home1.jpg'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'عقارات إيليت النخبة',
                    style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.verified, color: Colors.blue, size: 16),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                reel['title'] ?? 'وحدة سكنية فاخرة',
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.location_on, color: Colors.white70, size: 16),
                  const SizedBox(width: 4),
                  Text(
                    reel['location'] ?? 'القاهرة، مصر',
                    style: const TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppTheme.accentColor,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(color: AppTheme.accentColor.withOpacity(0.5), blurRadius: 10, offset: const Offset(0, 4)),
                      ],
                    ),
                    child: Text(
                      '${reel['price']} ج.م',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PropertyDetailsScreen(property: reel),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white.withOpacity(0.2),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    ),
                    child: const Text('احجز المعاينة الآن', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
              const SizedBox(height: 80), // Padding to clear bottom navigation
            ],
          ),
        ),

        // Side Actions (Bottom Right)
        Positioned(
          bottom: 110,
          left: 10,
          child: Column(
            children: [
              _buildReelAction(Icons.favorite_rounded, '1.2k', Colors.red, () {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الإعجاب بالوحدة ❤️')));
              }),
              _buildReelAction(Icons.comment_rounded, '85', Colors.white, () => _showComments(reel)),
              _buildReelAction(Icons.share_rounded, 'مشاركة', Colors.white, () {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('جاري إنشاء رابط إيليت... 🔗')));
              }),
              _buildReelAction(Icons.more_horiz_rounded, '', Colors.white, () {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('المزيد من الخيارات')));
              }),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildReelAction(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 24),
        child: Column(
          children: [
            Icon(icon, color: color, size: 36),
            if (label.isNotEmpty) const SizedBox(height: 6),
            if (label.isNotEmpty) Text(label, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  void _showComments(Map<String, dynamic> reel) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.6),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40, height: 4,
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: const BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.all(Radius.circular(2))),
                )
              ),
              const Text('تعليقات النخبة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              Expanded(
                child: ListView(
                  children: const [
                    ListTile(
                      leading: CircleAvatar(child: Text('ع', style: TextStyle(color: Colors.white)), backgroundColor: AppTheme.primaryColor),
                      title: Text('عبدالله محمد', style: TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('هل يمكن معاينة الوحدة غداً؟'),
                    ),
                    ListTile(
                      leading: CircleAvatar(child: Text('س', style: TextStyle(color: Colors.white)), backgroundColor: AppTheme.accentColor),
                      title: Text('سارة أحمد', style: TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('التشطيب في قمة الفخامة! ✨ المهندس أبدع.'),
                    ),
                  ],
                ),
              ),
              const Divider(),
              TextField(
                decoration: InputDecoration(
                  hintText: 'اكتب استفسارك للمستشار العقاري...',
                  hintStyle: const TextStyle(fontSize: 13),
                  suffixIcon: IconButton(icon: const Icon(Icons.send_rounded, color: AppTheme.primaryColor), onPressed: () => Navigator.pop(context)),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
                  filled: true,
                  fillColor: Colors.grey[200],
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }
}
