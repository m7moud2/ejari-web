import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:url_launcher/url_launcher.dart';
import '../widgets/elite_navigation_bar.dart';
import 'add_property_screen.dart';
import 'property_reels_screen.dart';
import 'properties_screen.dart';
import 'profile_screen.dart';
import '../theme/app_theme.dart';
import '../widgets/property_card.dart';
import '../widgets/offers_slider.dart';
import '../services/data_service.dart';
import 'booking_screen.dart';
import 'property_details_screen.dart';
import 'provider_registration_screen.dart';
import '../widgets/interactive_stories.dart';
import '../services/auth_service.dart';
import 'notifications_screen.dart';
import '../widgets/promoted_ads_slider.dart';
import 'search_results_screen.dart';
import 'advanced_filters_screen.dart';
import 'service_details_screen.dart';
import 'ai_chat_screen.dart';
import '../l10n/app_localizations.dart';
import 'for_sale_screen.dart';
import 'ai_concierge_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  String _currentRole = 'tenant';

  @override
  void initState() {
    super.initState();
    _loadRole();
  }

  Future<void> _loadRole() async {
    final role = await AuthService.getUserRole();
    setState(() => _currentRole = role);
  }

  Future<void> _launchWhatsApp() async {
    const url = "https://wa.me/201280083336";
    final uri = Uri.parse(url);
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (e) {
      debugPrint('Could not launch $url: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('عذراً، تعذر فتح واتساب. يرجى التأكد من تثبيت التطبيق.')),
        );
      }
    }
  }

  List<Widget> get _screens => [
    HomeContent(role: _currentRole),
    const PropertiesScreen(),
    const AddPropertyScreen(),
    const PropertyReelsScreen(),
    const ProfileScreen(),
  ];

  Offset _fabPosition = const Offset(20, 100);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          IndexedStack(
            index: _currentIndex,
            children: _screens,
          ),
          Positioned(
            right: _fabPosition.dx,
            bottom: _fabPosition.dy,
            child: GestureDetector(
              onPanUpdate: (details) {
                setState(() {
                  _fabPosition = Offset(
                    (_fabPosition.dx - details.delta.dx).clamp(10, size.width - 70),
                    (_fabPosition.dy - details.delta.dy).clamp(80, size.height - 100),
                  );
                });
              },
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FloatingActionButton.small(
                    heroTag: 'ai_support_mini',
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const AiConciergeScreen())),
                    backgroundColor: AppTheme.primaryColor,
                    child: const Icon(Icons.auto_awesome, color: AppTheme.accentColor, size: 20),
                  ),
                  const SizedBox(height: 8),
                  FloatingActionButton(
                    heroTag: 'whatsapp_support',
                    onPressed: () => _launchWhatsApp(),
                    backgroundColor: const Color(0xFF25D366),
                    elevation: 10,
                    child: const Icon(Icons.chat_rounded, color: Colors.white, size: 30),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: EliteNavigationBar(
        currentIndex: _currentIndex,
        role: _currentRole,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
          _loadRole();
        },
      ),
    );
  }
}


class HomeContent extends StatefulWidget {
  final String role;
  const HomeContent({super.key, this.role = 'tenant'});

  @override
  State<HomeContent> createState() => _HomeContentState();
}

class _HomeContentState extends State<HomeContent> {
  List<Map<String, dynamic>> _properties = [];
  List<Map<String, dynamic>> _filteredProperties = [];
  bool _isLoading = true;
  String? _selectedCategory;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    final properties = await DataService.getAllProperties();
    setState(() {
      _properties = properties;
      _filteredProperties = properties.where((p) => p['listingMode'] != 'for_sale').toList();
      _isLoading = false;
    });
  }

  void _filterByCategory(String? category) {
    setState(() {
      _selectedCategory = category;
      _applyFilters();
    });
  }

  void _performLiveSearch(String query) {
    setState(() {
      _applyFilters();
    });
  }

  void _applyFilters() {
    final query = _searchController.text.toLowerCase();

    // Map UI category label → internal type value
    const Map<String, String> typeMap = {
      'شقق كيو':       'شقق',
      'منطقة الفلل':   'فلل',
      'إسكان طلاب':   'استوديو',
      'مكاتب ومحلات':  'مكاتب',
      'إقامة فندقية':  'فندقي',
      'شاليهات':       'شاليهات',
    };

    _filteredProperties = _properties.where((p) {
      bool categoryMatch = true;
      if (_selectedCategory != null && _selectedCategory != 'الكل') {
        final mapped = typeMap[_selectedCategory!] ?? _selectedCategory!;
        categoryMatch = (p['type'] == mapped ||
                p['type']?.toString().toLowerCase() == mapped.toLowerCase()) &&
            p['listingMode'] != 'for_sale';
      }
      bool searchMatch = true;
      if (query.isNotEmpty) {
        final title = (p['title'] ?? '').toLowerCase();
        final location = (p['location'] ?? '').toLowerCase();
        searchMatch = title.contains(query) || location.contains(query);
      }
      return categoryMatch && searchMatch;
    }).toList();
  }

  Widget _buildSearchBar(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color ?? Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          const SizedBox(width: 16),
          const Icon(Icons.search_rounded, color: Colors.grey),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _searchController,
              onChanged: _performLiveSearch,
              onSubmitted: (value) {
                if (value.trim().isNotEmpty) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SearchResultsScreen(query: value)),
                  );
                }
              },
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: context.tr('search_hint'),
                hintStyle: const TextStyle(color: Colors.grey, fontSize: 13),
                border: InputBorder.none,
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          _searchController.clear();
                          _performLiveSearch('');
                        })
                    : null,
              ),
            ),
          ),
          Container(height: 50, width: 1, color: Colors.grey.withOpacity(0.2)),
          IconButton(
            icon: Icon(Icons.tune_rounded, color: Theme.of(context).iconTheme.color),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (context) => const AdvancedFiltersScreen())),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoriesGrid(BuildContext context) {
    final categories = [
      {'label': 'الكل',          'icon': Icons.apps_rounded,            'color': AppTheme.accentColor},
      {'label': 'شقق كيو',       'icon': Icons.apartment_rounded,       'color': const Color(0xFF2C3E50)},
      {'label': 'منطقة الفلل',   'icon': Icons.holiday_village_rounded, 'color': AppTheme.accentColor},
      {'label': 'إسكان طلاب',   'icon': Icons.school_rounded,          'color': const Color(0xFF8B5CF6)},
      {'label': 'مكاتب ومحلات', 'icon': Icons.business_center_rounded, 'color': const Color(0xFF10B981)},
      {'label': 'إقامة فندقية', 'icon': Icons.hotel_rounded,           'color': const Color(0xFF27AE60)},
      {'label': 'شاليهات',       'icon': Icons.beach_access_rounded,    'color': const Color(0xFF0EA5E9)},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              Icon(Icons.dashboard_customize_rounded, size: 20, color: AppTheme.accentColor),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'تصفح حسب الفئة',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Theme.of(context).textTheme.titleLarge?.color),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: categories.map((cat) {
              final label = cat['label'] as String;
              final icon = cat['icon'] as IconData;
              final color = cat['color'] as Color;
              return Padding(
                padding: const EdgeInsets.only(left: 12),
                child: _buildEliteCategory(context, label, icon, color),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final greetingText =
        widget.role == 'owner' ? 'مرحباً، مستثمر كيو' : 'مرحباً بك في كيو إيليت';
    final subtitleText = widget.role == 'owner'
        ? 'إدارة استثماراتك'
        : 'استأجر أفضل الشقق في كيو والمنطقة';

    return Scaffold(
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            // Beta Banner
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Color(0xFFD4AF37), Color(0xFFC5A028)]),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.info_outline, color: Colors.white, size: 16),
                  SizedBox(width: 8),
                  Text(
                    'نسخة تجريبية (Beta) - نحن في مرحلة التطوير والاختبار',
                    style: TextStyle(
                        color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Expanded(
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverAppBar(
                    expandedHeight: 180,
                    floating: true,
                    pinned: true,
                    elevation: 0,
                    backgroundColor: AppTheme.primaryColor,
                    flexibleSpace: FlexibleSpaceBar(
                      background: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.asset('assets/images/home1.jpg',
                              fit: BoxFit.cover,
                              color: Colors.black.withOpacity(0.5),
                              colorBlendMode: BlendMode.darken),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Colors.transparent,
                                  AppTheme.primaryColor.withOpacity(0.9)
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    bottom: PreferredSize(
                      preferredSize: const Size.fromHeight(100),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: _buildSearchBar(context),
                      ),
                    ),
                    title: Row(
                      children: [
                        Expanded(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      greetingText,
                                      style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFD4AF37).withOpacity(0.2),
                                      borderRadius: BorderRadius.circular(4),
                                      border: Border.all(
                                          color: const Color(0xFFD4AF37), width: 0.5),
                                    ),
                                    child: const Text('عضو مؤسس',
                                        style: TextStyle(
                                            color: Color(0xFFD4AF37),
                                            fontSize: 9,
                                            fontWeight: FontWeight.bold)),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(subtitleText,
                                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis),
                            ],
                          ),
                        ),
                      ],
                    ),
                    actions: [
                      IconButton(
                        icon: const Icon(Icons.notifications_active_rounded,
                            color: Color(0xFFF1C40F)),
                        onPressed: () => Navigator.push(context,
                            MaterialPageRoute(
                                builder: (context) => const NotificationsScreen())),
                      ),
                    ],
                  ),

                  SliverToBoxAdapter(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 16),
                        // Launch promo card
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFF6366F1), Color(0xFF8B5CF6)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                    color: const Color(0xFF6366F1).withOpacity(0.3),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4)),
                              ],
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'عرض الانطلاق التجريبي! 🚀',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16),
                                      ),
                                      const SizedBox(height: 4),
                                      const Text(
                                        'أول 100 عميل يحصلون على خصم 50% على جميع الخدمات لمدة شهر كامل.',
                                        style:
                                            TextStyle(color: Colors.white70, fontSize: 12),
                                      ),
                                      const SizedBox(height: 12),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(20),
                                        ),
                                        child: const Text(
                                          'باقي 87 مكان فقط!',
                                          style: TextStyle(
                                              color: Color(0xFF6366F1),
                                              fontWeight: FontWeight.bold,
                                              fontSize: 10),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Icon(Icons.stars_rounded, color: Colors.white, size: 48),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        const PromotedAdsSlider(),
                        const InteractiveStories(),
                        const SizedBox(height: 16),
                        const OffersSlider(),
                        const SizedBox(height: 24),
                        _buildCategoriesGrid(context),
                        const SizedBox(height: 16),
                        _buildForSaleBanner(context),
                        const SizedBox(height: 16),
                        _buildJoinProviderBanner(context),
                        const SizedBox(height: 32),
                        _buildEliteServicesSection(context),
                        const SizedBox(height: 32),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(context.tr('elite_portfolio'),
                                    style: const TextStyle(
                                        fontSize: 20, fontWeight: FontWeight.w900),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis),
                              ),
                              TextButton(
                                onPressed: () => Navigator.push(context,
                                    MaterialPageRoute(
                                        builder: (context) => const PropertiesScreen())),
                                child: Text(context.tr('view_all'),
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: AppTheme.primaryColor)),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                      ],
                    ),
                  ),

                  _isLoading
                      ? const SliverToBoxAdapter(
                          child: SizedBox(
                              height: 200,
                              child: Center(child: CircularProgressIndicator())))
                      : SliverPadding(
                          padding: const EdgeInsets.only(bottom: 120),
                          sliver: SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, index) {
                                final property = _filteredProperties[index];
                                return PropertyCard(
                                  id: property['id'] ?? '0',
                                  title: property['title'] ?? '',
                                  price: property['price'] ?? '0',
                                  location: property['location'] ?? '',
                                  image: property['image'] ??
                                      'assets/images/home1.jpg',
                                  beds: property['beds'] ?? '0',
                                  baths: property['baths'] ?? '0',
                                  area: property['area'] ?? '0',
                                  listingMode: property['listingMode'],
                                  isDemo: property['isDemo'] ?? false,
                                  onTap: () => Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              PropertyDetailsScreen(
                                                  property: property))),
                                  onBook: () => Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => BookingScreen(
                                              itemType: 'property',
                                              itemData: property))),
                                );
                              },
                              childCount: _filteredProperties.length,
                            ),
                          ),
                        ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildJoinProviderBanner(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GestureDetector(
        onTap: () => Navigator.push(context,
            MaterialPageRoute(
                builder: (context) => const ProviderRegistrationScreen())),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF27AE60), Color(0xFF2ECC71)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                  color: const Color(0xFF27AE60).withOpacity(0.3),
                  blurRadius: 15,
                  offset: const Offset(0, 8))
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                right: -20,
                bottom: -20,
                child: Icon(Icons.build_circle_rounded,
                    size: 100, color: Colors.white.withOpacity(0.15)),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    const Icon(Icons.engineering_rounded, color: Colors.white, size: 36),
                    const SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('انضم لشركاء النجاح 👷‍♂️',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 16)),
                          SizedBox(height: 4),
                          Text('سجل كفني أو مقدم خدمة وابدأ جني الأرباح معنا',
                              style: TextStyle(color: Colors.white, fontSize: 11)),
                        ],
                      ),
                    ),
                    const Icon(Icons.add_circle_outline_rounded,
                        color: Colors.white, size: 24),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildForSaleBanner(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppTheme.primaryColor,
          borderRadius: BorderRadius.circular(24),
          image: DecorationImage(
            image: const AssetImage('assets/images/home2.jpg'),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
                AppTheme.primaryColor.withOpacity(0.8), BlendMode.darken),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('هل تبحث عن استثمار حقيقي؟ 🏠',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 8),
            const Text(
                'تصفح قائمة الوحدات المتاحة للبيع بأفضل الأسعار في القليوبية.',
                style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const ForSaleScreen())),
              style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.accentColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12))),
              child: const Text('عرض العقارات للبيع',
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEliteCategory(
      BuildContext context, String title, IconData icon, Color color) {
    bool isSelected = _selectedCategory == title;
    return GestureDetector(
      onTap: () => _filterByCategory(isSelected ? null : title),
      child: Column(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              color: isSelected
                  ? color
                  : (Theme.of(context).brightness == Brightness.light
                      ? const Color(0xFFF8FAFC)
                      : const Color(0xFFD8C49F)),
              borderRadius: BorderRadius.circular(20),
              border:
                  Border.all(color: isSelected ? color : Colors.grey.shade200, width: 2),
            ),
            child: Icon(icon, color: isSelected ? Colors.white : color, size: 28),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: 70,
            child: Text(
              title,
              style: TextStyle(
                  fontWeight: isSelected ? FontWeight.w900 : FontWeight.bold,
                  fontSize: 11,
                  color: isSelected
                      ? color
                      : (Theme.of(context).textTheme.bodyMedium?.color ??
                          Colors.black87)),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEliteServicesSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              const Icon(Icons.workspace_premium_rounded,
                  size: 20, color: Color(0xFFD4AF37)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  context.tr('property_management_services'),
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF1F2937)),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              _buildServiceCard(
                  context,
                  context.tr('safe_transport'),
                  Icons.local_shipping_rounded,
                  const Color(0xFF34495E),
                  context.tr('safe_transport_desc'),
                  2000),
              _buildServiceCard(
                  context,
                  context.tr('hotel_cleaning'),
                  Icons.cleaning_services_rounded,
                  const Color(0xFF2980B9),
                  context.tr('hotel_cleaning_desc'),
                  600),
              _buildServiceCard(
                  context,
                  context.tr('emergency_maintenance'),
                  Icons.car_repair_rounded,
                  const Color(0xFFD35400),
                  context.tr('emergency_maintenance_desc'),
                  450),
              _buildServiceCard(
                  context,
                  context.tr('smart_design'),
                  Icons.format_paint_rounded,
                  const Color(0xFF8E44AD),
                  context.tr('smart_design_desc'),
                  5000),
              _buildServiceCard(
                  context,
                  context.tr('ai_concierge'),
                  Icons.smart_toy_rounded,
                  const Color(0xFF6A1B9A),
                  context.tr('ai_concierge_desc'),
                  0),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildServiceCard(BuildContext context, String title, IconData icon,
      Color color, String desc, int price) {
    return _AnimatedGlassCard(
      title: title,
      icon: icon,
      color: color,
      desc: desc,
      price: price,
    );
  }
}

class _AnimatedGlassCard extends StatefulWidget {
  final String title;
  final IconData icon;
  final Color color;
  final String desc;
  final int price;

  const _AnimatedGlassCard({
    required this.title,
    required this.icon,
    required this.color,
    required this.desc,
    required this.price,
  });

  @override
  State<_AnimatedGlassCard> createState() => _AnimatedGlassCardState();
}

class _AnimatedGlassCardState extends State<_AnimatedGlassCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 150));
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
        CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                widget.title == context.tr('ai_concierge') ||
                        widget.title == 'AI Concierge'
                    ? const AiConciergeScreen()
                    : ServiceDetailsScreen(
                        serviceName: widget.title,
                        description: widget.desc,
                        icon: widget.icon,
                        color: widget.color,
                        basePrice: widget.price,
                      ),
          ),
        );
      },
      onTapCancel: () => _controller.reverse(),
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Container(
          width: 170,
          margin: const EdgeInsets.only(right: 12),
          decoration: BoxDecoration(
            color: Theme.of(context).cardTheme.color ?? Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
                color: Theme.of(context).brightness == Brightness.light
                    ? Colors.grey[200]!
                    : Colors.grey[800]!,
                width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 10,
                  offset: const Offset(0, 5))
            ],
          ),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: widget.color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12)),
                child: Icon(widget.icon, color: widget.color, size: 28),
              ),
              const SizedBox(height: 16),
              Text(
                widget.title,
                style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                    color: Theme.of(context).textTheme.titleMedium?.color ??
                        AppTheme.textPrimary),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 8),
              Text(
                widget.price == 0
                    ? context.tr('free_price')
                    : '${context.tr('starts_from')} ${widget.price} ${context.tr('price_egp')}',
                style: TextStyle(
                    color: widget.color,
                    fontWeight: FontWeight.bold,
                    fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
