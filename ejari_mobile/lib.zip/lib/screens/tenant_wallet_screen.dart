import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/wallet_service.dart';
import 'package:intl/intl.dart';
import 'payment_methods_screen.dart';
import 'rewards_screen.dart';

class TenantWalletScreen extends StatefulWidget {
  const TenantWalletScreen({super.key});

  @override
  State<TenantWalletScreen> createState() => _TenantWalletScreenState();
}

class _TenantWalletScreenState extends State<TenantWalletScreen> {
  double _balance = 0.0;
  List<Map<String, dynamic>> _transactions = [];
  String _selectedFilter = 'الكل'; // 'الكل', 'إيداع', 'سحب'
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadWalletData();
  }

  Future<void> _loadWalletData() async {
    await WalletService.init();
    final balance = await WalletService.getBalance();
    final transactions = await WalletService.getTransactions();

    if (mounted) {
      setState(() {
        _balance = balance;
        _transactions = transactions;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        elevation: 0,
        title: Text('المحفظة المالية', style: TextStyle(color: Theme.of(context).textTheme.titleLarge?.color, fontWeight: FontWeight.bold, fontSize: 18)),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: Theme.of(context).iconTheme.color, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: _loadWalletData,
            color: AppTheme.primaryColor,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                children: [
                  _buildBalanceCard(),
                  const SizedBox(height: 24),
                  _buildQuickActions(),
                  const SizedBox(height: 32),
                  _buildTransactionHistory(),
                ],
              ),
            ),
          ),
    );
  }

  Widget _buildBalanceCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFBCA374), Color(0xFFD8C49F)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 25, offset: const Offset(0, 15)),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -20,
            top: -20,
            child: Icon(Icons.wifi_rounded, size: 100, color: Colors.white.withOpacity(0.05)),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Keyo Elite', style: TextStyle(color: Color(0xFFF1C40F), fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                  Icon(Icons.contactless_rounded, color: Colors.white.withOpacity(0.5), size: 28),
                ],
              ),
              const SizedBox(height: 32),
              const Text('الرصيد المتاح', style: TextStyle(color: Colors.white54, fontSize: 12)),
              const SizedBox(height: 8),
              Text(
                '${NumberFormat('#,##0.00').format(_balance)} ج.م',
                style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.bold, letterSpacing: -0.5),
              ),
              const SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildBalanceAction(Icons.add_circle_outline_rounded, 'شحن الرصيد', _showTopUpDialog),
                  _buildBalanceAction(Icons.arrow_circle_up_rounded, 'تحويل', _showQuickPayDialog),
                  _buildBalanceAction(Icons.receipt_long_rounded, 'الكشوفات', () {}),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showTopUpDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('شحن المحفظة', style: TextStyle(fontWeight: FontWeight.bold)),
        content: const Text('هل ترغب بإضافة 5000 ج.م للمحفظة كتجربة؟', style: TextStyle(color: Colors.grey)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryColor, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () async {
              Navigator.pop(context);
              setState(() => _isLoading = true);
              await WalletService.topUpWallet(5000.0);
              await _loadWalletData();
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الشحن 💳'), backgroundColor: Colors.green));
            },
            child: const Text('تأكيد الشحن', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showQuickPayDialog() {
    final TextEditingController amountController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('تحويل استثماري', style: TextStyle(fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'المبلغ (ج.م)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                filled: true,
                fillColor: const Color(0xFFF8FAFC)
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryColor, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () async {
              final amount = double.tryParse(amountController.text);
              if (amount == null || amount <= 0) return;

              Navigator.pop(context);
              setState(() => _isLoading = true);
              
              final success = await WalletService.payFromWallet(
                title: 'تحويل معتمد',
                amount: amount,
                category: 'service',
                bookingId: 'SVC-${DateTime.now().millisecondsSinceEpoch}',
              );

              await _loadWalletData();
              
              if (context.mounted) {
                 if (success) {
                   ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم التحويل ✅'), backgroundColor: Colors.green));
                 } else {
                   ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرصيد غير كافٍ'), backgroundColor: Colors.red));
                 }
              }
            },
            child: const Text('تحويل', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildBalanceAction(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 24),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _buildQuickActions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const PaymentMethodsScreen())),
              child: _buildActionCard('بطاقات الائتمان', 'إدارة البطاقات', Icons.credit_score_rounded, Colors.purple),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const RewardsScreen())),
              child: _buildActionCard('المكافآت', 'نقاط وعروض', Icons.workspace_premium_rounded, const Color(0xFFF1C40F)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard(String title, String subtitle, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color ?? Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor.withOpacity(0.1)),
        boxShadow: [BoxShadow(color: Theme.of(context).brightness == Brightness.light ? Colors.black.withOpacity(0.02) : Colors.transparent, blurRadius: 10, offset: const Offset(0, 5))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 4),
          Text(subtitle, style: TextStyle(color: Colors.grey[500], fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildTransactionHistory() {
    final filteredTransactions = _transactions.where((t) {
      if (_selectedFilter == 'الكل') return true;
      if (_selectedFilter == 'إيداع') return t['type'] == 'credit';
      if (_selectedFilter == 'سحب') return t['type'] == 'expense';
      return true;
    }).toList();

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color ?? Theme.of(context).cardColor,
        borderRadius: BorderRadius.vertical(top: const Radius.circular(32)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('سجل العمليات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.titleLarge?.color)),
              Text('${filteredTransactions.length} عملية', style: const TextStyle(color: Colors.grey, fontSize: 12, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 24),
          
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ['الكل', 'إيداع', 'سحب'].map((filter) {
                final isSelected = _selectedFilter == filter;
                return Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: ChoiceChip(
                    label: Text(filter),
                    selected: isSelected,
                    onSelected: (selected) {
                      if (selected) setState(() => _selectedFilter = filter);
                    },
                    selectedColor: AppTheme.primaryColor.withOpacity(0.1),
                    backgroundColor: Theme.of(context).brightness == Brightness.light ? const Color(0xFFF8FAFC) : Colors.white.withOpacity(0.05),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: isSelected ? AppTheme.primaryColor.withOpacity(0.5) : Colors.transparent)),
                    labelStyle: TextStyle(
                      color: isSelected ? AppTheme.primaryColor : Colors.grey,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      fontSize: 13,
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 24),

          if (filteredTransactions.isEmpty)
            const Center(child: Padding(padding: EdgeInsets.symmetric(vertical: 40), child: Text('لا توجد معاملات تطابق الفلتر', style: TextStyle(color: Colors.grey))))
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: filteredTransactions.length,
              itemBuilder: (context, index) {
                final transaction = filteredTransactions[index];
                final isExpense = transaction['type'] == 'expense';
                final DateTime date = DateTime.tryParse(transaction['date']) ?? DateTime.now();
                
                return InkWell(
                  onTap: () => _showTransactionDetails(transaction),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.shade100))),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: isExpense ? const Color(0xFFFDF2F2) : const Color(0xFFF1FAF5), shape: BoxShape.circle),
                          child: Icon(isExpense ? Icons.arrow_outward_rounded : Icons.arrow_downward_rounded, color: isExpense ? Colors.red : Colors.green, size: 20),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(transaction['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                              const SizedBox(height: 4),
                              Text(DateFormat('dd MMM yyyy, hh:mm a').format(date), style: TextStyle(color: Colors.grey[500], fontSize: 11)),
                            ],
                          ),
                        ),
                        Text(
                          '${isExpense ? '-' : '+'}${NumberFormat('#,##0').format((transaction['amount'] as num).abs())}',
                          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: isExpense ? Colors.red : Colors.green),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  void _showTransactionDetails(Map<String, dynamic> tx) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
      builder: (context) => Container(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('إيصال المعاملة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 32),
            CircleAvatar(
              radius: 30,
              backgroundColor: tx['type'] == 'expense' ? const Color(0xFFFDF2F2) : const Color(0xFFF1FAF5),
              child: Icon(tx['type'] == 'expense' ? Icons.payment_rounded : Icons.account_balance_wallet_rounded, color: tx['type'] == 'expense' ? Colors.red : Colors.green, size: 30),
            ),
            const SizedBox(height: 16),
            Text('${tx['amount']} ج.م', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: -1)),
            Text(tx['title'] ?? '', style: const TextStyle(color: Colors.grey)),
            const Divider(height: 40),
            _buildDetailRow('الحالة', 'مكتملة الموثوقية ✅'),
            _buildDetailRow('الرقم المرجعي', 'TXN-${DateTime.now().millisecondsSinceEpoch}'),
            _buildDetailRow('التاريخ', DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.parse(tx['date']))),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: () {
                   Navigator.pop(context);
                   ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تصدير الإيصال البنكي 📄')));
                },
                icon: const Icon(Icons.share_rounded, color: Colors.white),
                label: const Text('تصدير كوثيقة', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryColor, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey)),
          Text(value, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.bodyLarge?.color)),
        ],
      ),
    );
  }
}
