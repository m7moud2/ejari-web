import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class FirebaseService {
  static bool isInitialized = false;

  /// Initializes Firebase safely without crashing if google-services.json is missing
  static Future<void> initialize() async {
    try {
      await Firebase.initializeApp();
      isInitialized = true;
      if (kDebugMode) {
        print('✅ Firebase Initialized Successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('⚠️ Firebase Initialization Failed or Skipped:');
        print('Make sure google-services.json is added to android/app and GoogleService-Info.plist to ios/Runner.');
        print('Error Details: $e');
      }
      isInitialized = false;
    }
  }

  // Future methods for Auth and DB can be added here
  // e.g. static Future<User?> login(...)
}
