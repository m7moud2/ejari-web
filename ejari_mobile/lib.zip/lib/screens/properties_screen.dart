import 'package:flutter/material.dart';
import '../widgets/property_card.dart';
import '../theme/app_theme.dart';
import 'property_details_screen.dart';
import 'booking_screen.dart';
import '../services/data_service.dart';

class PropertiesScreen extends StatefulWidget {
  const PropertiesScreen({super.key});

  @override
  State<PropertiesScreen> createState() => _PropertiesScreenState();
}

class _PropertiesScreenState extends State<PropertiesScreen> {
  String _selectedType = 'الكل';
  List<Map<String, dynamic>> _allProperties = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProperties();
  }

  Future<void> _loadProperties() async {
    final properties = await DataService.getAllProperties();
    if (mounted) {
      setState(() {
        _allProperties = properties;
        _isLoading = false;
      });
    }
  }

  List<Map<String, dynamic>> get _filteredProperties {
    if (_selectedType == 'الكل') {
      return _allProperties;
    }
    const typeMapping = {
      'شقة': 'شقق',
      'فيلا': 'فلل',
      'استوديو': 'استوديو',
      'دوبلكس': 'دوبلكس',
    };
    final targetType = typeMapping[_selectedType] ?? _selectedType;
    return _allProperties
        .where((prop) => prop['type'] == targetType)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('العقارات المتاحة'),
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Filter Chips
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildFilterChip('الكل', _selectedType == 'الكل', () {
                    setState(() => _selectedType = 'الكل');
                  }),
                  _buildFilterChip('شقة', _selectedType == 'شقة', () {
                    setState(() => _selectedType = 'شقة');
                  }),
                  _buildFilterChip('فيلا', _selectedType == 'فيلا', () {
                    setState(() => _selectedType = 'فيلا');
                  }),
                  _buildFilterChip('استوديو', _selectedType == 'استوديو', () {
                    setState(() => _selectedType = 'استوديو');
                  }),
                  _buildFilterChip('دوبلكس', _selectedType == 'دوبلكس', () {
                    setState(() => _selectedType = 'دوبلكس');
                  }),
                ],
              ),
            ),
          ),

          // Results Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Text(
              'عدد النتائج: ${_filteredProperties.length}',
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 14,
              ),
            ),
          ),

          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredProperties.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.apartment,
                                size: 80, color: Colors.grey[300]),
                            const SizedBox(height: 16),
                            const Text(
                              'لا توجد عقارات متاحة',
                              style: TextStyle(
                                color: AppTheme.textSecondary,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.only(bottom: 16),
                        itemCount: _filteredProperties.length,
                        itemBuilder: (context, index) {
                          final property = _filteredProperties[index];
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            child: PropertyCard(
                              id: property['id'] ?? '0',
                              title: property['title'],
                              price: property['price'],
                              location: property['location'],
                              image: property['image'],
                              beds: property['beds'],
                              baths: property['baths'],
                              area: property['area'],
                              listingMode: property['listingMode'],
                              isDemo: property['isDemo'] ?? false,
                              onTap: () => _navigateToDetails(property),
                              onBook: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => BookingScreen(
                                      itemType: 'property',
                                      itemData: property,
                                    ),
                                  ),
                                );
                              },
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  void _navigateToDetails(Map<String, dynamic> property) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PropertyDetailsScreen(property: property),
      ),
    );
  }

  Widget _buildFilterChip(String label, bool isSelected, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.only(left: 8),
      child: FilterChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (bool value) => onTap(),
        backgroundColor: Colors.white,
        selectedColor: AppTheme.primaryColor.withOpacity(0.1),
        labelStyle: TextStyle(
          color: isSelected ? AppTheme.primaryColor : AppTheme.textSecondary,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(
            color: isSelected ? AppTheme.primaryColor : Colors.grey[300]!,
          ),
        ),
        showCheckmark: false,
      ),
    );
  }
}
