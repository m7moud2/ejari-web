import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ألوان النخبة الفاخرة - كيو (Keyo Quiet Luxury Theme)
  static const Color primaryColor = Color(0xFF0A0E17); // أسود أو بسيديان داكن (Obsidian Black)
  static const Color secondaryColor = Color(0xFFD8C49F); // ذهبي شامبين فاتح (Champagne Gold Light)
  static const Color accentColor = Color(0xFFBCA374); // ذهبي مطفي فاخر (Matte Champagne Gold)
  static const Color backgroundColor = Color(0xFFFBFBFA); // خلفية عاجية دافئة (Luxury Ivory/Alabaster)
  static const Color surfaceColor = Colors.white;
  static const Color textPrimary = Color(0xFF2C333F); // رمادي فحمي داكن ومريح للقراءة
  static const Color textSecondary = Color(0xFF6B7280); // رمادي متوسط بتباين ممتاز

  // ألوان الوضع الداكن (Obsidian Dark Mode)
  static const Color primaryColorDark = Color(0xFF05070A);
  static const Color backgroundColorDark = Color(0xFF0A0E17);
  static const Color surfaceColorDark = Color(0xFF161C2A);
  static const Color textPrimaryDark = Color(0xFFF9FAFB);
  static const Color textSecondaryDark = Color(0xFF9CA3AF);

  // تأثير الزجاج (Glassmorphism)
  static Color glassColor(BuildContext context) => 
      Theme.of(context).brightness == Brightness.light 
          ? Colors.white.withOpacity(0.45) 
          : const Color(0xFF161C2A).withOpacity(0.65);

  static ThemeData get lightTheme {
    return ThemeData(
      brightness: Brightness.light,
      primaryColor: primaryColor,
      scaffoldBackgroundColor: backgroundColor,
      
      // إعداد الخطوط (Tajawal)
      textTheme: GoogleFonts.tajawalTextTheme(ThemeData.light().textTheme).copyWith(
        bodyLarge: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.5, fontSize: 16, color: textPrimary)),
        bodyMedium: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.5, fontSize: 14, color: textPrimary)),
        bodySmall: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.4, fontSize: 12, color: textSecondary)),
        titleLarge: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.4, fontWeight: FontWeight.bold, color: textPrimary)),
        titleMedium: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.4, fontWeight: FontWeight.bold, color: textPrimary)),
        titleSmall: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.4, fontWeight: FontWeight.bold, color: textPrimary)),
      ).apply(
        bodyColor: textPrimary,
        displayColor: textPrimary,
      ),

      colorScheme: ColorScheme.fromSwatch().copyWith(
        primary: primaryColor,
        secondary: accentColor,
        surface: surfaceColor,
        brightness: Brightness.light,
      ),

      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: textPrimary,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.tajawal(
          color: textPrimary,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        iconTheme: const IconThemeData(color: textPrimary),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          textStyle: GoogleFonts.tajawal(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8), // تصميم حاد وراقٍ أكثر
          ),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          elevation: 0, // إلغاء الظلال القوية
        ),
      ),

      cardTheme: CardTheme(
        color: surfaceColor,
        elevation: 2,
        shadowColor: Colors.black.withOpacity(0.02),
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFFF3F4F6), width: 1),
        ),
        margin: const EdgeInsets.only(bottom: 20),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceColor,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: accentColor, width: 1.5),
        ),
        hintStyle: GoogleFonts.tajawal(color: textSecondary, fontSize: 14),
      ),
      
      useMaterial3: true,
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      primaryColor: accentColor,
      scaffoldBackgroundColor: backgroundColorDark,
      
      textTheme: GoogleFonts.tajawalTextTheme(ThemeData.dark().textTheme).copyWith(
        bodyLarge: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.5, fontSize: 16, color: textPrimaryDark)),
        bodyMedium: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.5, fontSize: 14, color: textPrimaryDark)),
        bodySmall: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.4, fontSize: 12, color: textSecondaryDark)),
        titleLarge: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.4, fontWeight: FontWeight.bold, color: textPrimaryDark)),
        titleMedium: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.4, fontWeight: FontWeight.bold, color: textPrimaryDark)),
        titleSmall: GoogleFonts.tajawal(textStyle: const TextStyle(height: 1.4, fontWeight: FontWeight.bold, color: textPrimaryDark)),
      ).apply(
        bodyColor: textPrimaryDark,
        displayColor: textPrimaryDark,
      ),

      colorScheme: ColorScheme.fromSwatch(brightness: Brightness.dark).copyWith(
        primary: accentColor,
        secondary: secondaryColor,
        surface: surfaceColorDark,
        brightness: Brightness.dark,
      ),

      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: textPrimaryDark,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.tajawal(
          color: textPrimaryDark,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        iconTheme: const IconThemeData(color: textPrimaryDark),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: accentColor,
          foregroundColor: primaryColorDark,
          textStyle: GoogleFonts.tajawal(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          elevation: 0,
        ),
      ),

      cardTheme: CardTheme(
        color: surfaceColorDark,
        elevation: 2,
        shadowColor: Colors.black.withOpacity(0.05),
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFF1E293B), width: 1),
        ),
        margin: const EdgeInsets.only(bottom: 20),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceColorDark,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF1E293B)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF1E293B)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: accentColor, width: 1.5),
        ),
        hintStyle: GoogleFonts.tajawal(color: textSecondaryDark, fontSize: 14),
      ),
      
      useMaterial3: true,
    );
  }
}
