import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'signature_screen.dart';

class ContractScreen extends StatefulWidget {
  final String? contractId;
  final String ownerName;
  final String tenantName;
  final String propertyTitle;
  final String price;
  final String startDate;
  final String duration;
  final String? address;
  final String? deposit;
  final bool signedByOwner;
  final bool signedByTenant;
  final bool isOwner;
  final String itemLabel; // 'العقار' or 'السيارة'

  const ContractScreen({
    super.key,
    this.contractId,
    required this.ownerName,
    required this.tenantName,
    required this.propertyTitle,
    required this.price,
    required this.startDate,
    required this.duration,
    this.address,
    this.deposit,
    this.signedByOwner = false,
    this.signedByTenant = false,
    this.isOwner = false,
    this.itemLabel = 'العقار',
  });

  @override
  State<ContractScreen> createState() => _ContractScreenState();
}

class _ContractScreenState extends State<ContractScreen> {
  bool _isAgreed = false;
  bool _isElectronicSigned = false; // Electronic (Tap/Token)
  List<Offset?> _manualSignaturePoints = []; // Manual (Handwritten)

  bool get _isFullySigned => _isElectronicSigned && _manualSignaturePoints.isNotEmpty;

  @override
  void initState() {
    super.initState();
    // Pre-fill signature state if already signed
    if ((widget.isOwner && widget.signedByOwner) ||
        (!widget.isOwner && widget.signedByTenant)) {
      _isElectronicSigned = true;
      // We assume manual signature is already done if signed (simulation)
      // For now we won't restore points as we don't save them in this demo flow yet,
      // but we can set a dummy point to satisfy validation if viewing history.
      // But typically this screen is for Signing.
      _isAgreed = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('توقيع العقد الإلكتروني ✍️')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Safe Transaction Badge
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.green),
              ),
              child: Row(
                children: const [
                  Icon(Icons.gavel, color: Colors.green),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'هذا العقد ملزم قانونياً ويحفظ حقوق الطرفين وفقاً لقوانين الإيجار المصرية.',
                      style: TextStyle(color: Colors.green, fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Mediator Guarantee
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFFBCA374), Color(0xFFD8C49F)]),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10)],
              ),
              child: Row(
                children: [
                  const Icon(Icons.shield_rounded, color: Color(0xFFD4AF37), size: 28),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text('ضمان كيو إيليت (الوسيط الضامن)', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                        SizedBox(height: 4),
                        Text('نحن نضمن تحويل الأموال وتوثيق العقود وحفظ حقوق الملكية لكافة الأطراف.', style: TextStyle(color: Colors.white70, fontSize: 11)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Contract Content
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.grey[200]!),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 20)],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Center(
                    child: Column(
                      children: [
                        Text('عقد إيجار إلكتروني موثق', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: const Color(0xFF1F2937))),
                        Text('وفقاً لقوانين وزارة الإسكان والمرافق والمجتمعات العمرانية', style: TextStyle(fontSize: 10, color: Colors.grey)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Divider(),
                  _buildContractRow('الطرف الأول (المؤجر):', widget.ownerName),
                  _buildContractRow('الطرف الثاني (المستأجر):', widget.tenantName),
                  const Divider(),
                  _buildContractRow('${widget.itemLabel}:', widget.propertyTitle),
                  _buildContractRow('مدة الإيجار:', widget.duration),
                  _buildContractRow('تاريخ البدء:', widget.startDate),
                  _buildContractRow('القيمة الكيوة:', '${widget.price} ج.م'),
                  const Divider(),
                  const SizedBox(height: 10),
                  const Text('البنود القانونية الملزمة:', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primaryColor)),
                  const SizedBox(height: 12),
                  Text(
                    'المادة الأولى: يقر الطرف الثاني بمعاينة ${widget.itemLabel} المعاينة التامة النافية للجهالة وقبوله بالحالة التي عليها.\n'
                    'المادة الثانية: يلتزم الطرف الثاني بسداد القيمة الكيوة المتفق عليها عبر منصة كيو إيليت في موعد غايته اليوم الخامس من كل شهر.\n'
                    'المادة الثالثة: منصة كيو إيليت هي الوسيط التكنولوجي والضامن المالي، ويعد التوقيع الإلكتروني عبرها بمثابة توقيع رسمي ملزم أمام الجهات القضائية.\n'
                    'المادة الرابعة: يلتزم الطرف الأول بصيانة الأجزاء الهيكلية والمرافق الأساسية للوحدة لضمان انتفاع الطرف الثاني بها.\n'
                    'المادة الخامسة: في حالة الإخلال بأي بند، يحق للمنصة اتخاذ الإجراءات القانونية اللازمة لرد الحقوق لأصحابها.',
                    style: TextStyle(height: 1.8, fontSize: 12, color: Colors.grey[800]),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 24),

            // Terms Checkbox
            CheckboxListTile(
              value: _isAgreed,
              onChanged: (value) => setState(() => _isAgreed = value ?? false),
              title: const Text('أوافق على الشروط والأحكام وأقر بصحة البيانات.'),
              activeColor: AppTheme.primaryColor,
              contentPadding: EdgeInsets.zero,
            ),

            const SizedBox(height: 24),

            // 1. Manual Signature (Handwritten)
            Row(
              children: const [
                Icon(Icons.draw, color: AppTheme.primaryColor),
                SizedBox(width: 8),
                Text('1. التوقيع اليدوي (مطلوب)', style: TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SignatureScreen(
                      onSigned: (points) {
                        setState(() => _manualSignaturePoints = points);
                      },
                    ),
                  ),
                );
              },
              child: Container(
                height: 150,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey[50],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _manualSignaturePoints.isNotEmpty ? Colors.green : Colors.grey[400]!,
                    width: 2,
                  ),
                ),
                child: _manualSignaturePoints.isNotEmpty
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: CustomPaint(
                          painter: SignaturePainter(_manualSignaturePoints),
                          size: Size.infinite,
                        ),
                      )
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.touch_app, color: Colors.grey, size: 40),
                          SizedBox(height: 8),
                          Text('اضغط هنا لرسم توقيعك', style: TextStyle(color: Colors.grey)),
                        ],
                      ),
              ),
            ),
            if (_manualSignaturePoints.isNotEmpty)
              const Padding(
                 padding: EdgeInsets.only(top: 4),
                 child: Text('تم التوقيع اليدوي بنجاح ✅', style: TextStyle(color: Colors.green, fontSize: 12)),
              ),

            const SizedBox(height: 24),

            // 2. Electronic Signature (Token)
            Row(
              children: const [
                Icon(Icons.fingerprint, color: AppTheme.primaryColor),
                SizedBox(width: 8),
                Text('2. التوقيع الإلكتروني (مطلوب)', style: TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: () {
                if (!_isAgreed) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('يجب الموافقة على الشروط أولاً')),
                  );
                  return;
                }
                setState(() => _isElectronicSigned = !_isElectronicSigned);
              },
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _isElectronicSigned ? AppTheme.primaryColor.withOpacity(0.1) : Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _isElectronicSigned ? AppTheme.primaryColor : Colors.grey[400]!,
                    width: 2,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                         color: _isElectronicSigned ? AppTheme.primaryColor : Colors.grey[400],
                         shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.fingerprint, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _isElectronicSigned ? 'تم التوقيع الإلكتروني' : 'اضغط للتوقيع الإلكتروني',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: _isElectronicSigned ? AppTheme.primaryColor : Colors.grey[600],
                          ),
                        ),
                        if (_isElectronicSigned)
                          Text(
                            'Signed by: ${widget.tenantName}',
                            style: TextStyle(fontSize: 12, color: AppTheme.primaryColor.withOpacity(0.8)),
                          ),
                      ],
                    ),
                    const Spacer(),
                    if (_isElectronicSigned)
                      const Icon(Icons.check_circle, color: AppTheme.primaryColor),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 32),

            // Confirm Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: (_isAgreed && _isFullySigned)
                    ? () => Navigator.pop(context, true)
                    : null,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  backgroundColor: AppTheme.primaryColor,
                ),
                child: const Text('اعتماد العقد والمتابعة', style: TextStyle(fontSize: 18, color: Colors.white)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildContractRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        ],
      ),
    );
  }
}
