import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:ui';
import '../theme/app_theme.dart';
import '../services/data_service.dart';

class LoyaltyScreen extends StatefulWidget {
  const LoyaltyScreen({super.key});

  @override
  State<LoyaltyScreen> createState() => _LoyaltyScreenState();
}

class _LoyaltyScreenState extends State<LoyaltyScreen> with SingleTickerProviderStateMixin {
  late AnimationController _cardController;
  late Animation<double> _shineAnimation;
  int _points = 0;
  int _balance = 0;

  @override
  void initState() {
    super.initState();
    _cardController = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: false);
    _shineAnimation = Tween<double>(begin: -1.0, end: 2.0).animate(CurvedAnimation(parent: _cardController, curve: Curves.easeInOutSine));
    _loadLoyaltyData();
  }

  Future<void> _loadLoyaltyData() async {
    final properties = await DataService.getAllProperties();
    if (mounted) {
      setState(() {
        _points = properties.length * 1250; 
        _balance = properties.length * 120;
      });
    }
  }

  @override
  void dispose() {
    _cardController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryColor, // Obsidian Black Background
      appBar: AppBar(
        title: const Text('Elite Black Card', style: TextStyle(color: AppTheme.accentColor, fontWeight: FontWeight.bold, fontFamily: 'Serif')),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            _buildBlackCard(),
            const SizedBox(height: 40),
            _buildPointsStats(),
            const SizedBox(height: 30),
            _buildRewardsSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildBlackCard() {
    return AnimatedBuilder(
      animation: _shineAnimation,
      builder: (context, child) {
        return Container(
          height: 220,
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: const LinearGradient(
              colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: AppTheme.accentColor.withOpacity(0.1),
                blurRadius: 20,
                offset: const Offset(0, 10),
              )
            ],
            border: Border.all(color: AppTheme.accentColor.withOpacity(0.3), width: 1.5),
          ),
          child: Stack(
            children: [
              // Shine Effect
              Positioned.fill(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: FractionallySizedBox(
                    widthFactor: 0.3,
                    alignment: FractionalOffset(_shineAnimation.value, 0),
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withOpacity(0.0),
                            Colors.white.withOpacity(0.15),
                            Colors.white.withOpacity(0.0),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Text('KEYO ELITE', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2)),
                        Icon(Icons.nfc, color: AppTheme.accentColor),
                      ],
                    ),
                    const Text('1234  5678  9012  ****', style: TextStyle(color: Colors.white70, fontSize: 18, letterSpacing: 3, fontFamily: 'monospace')),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('MAHMOUD ABDELKAWY', style: TextStyle(color: Colors.white70, fontSize: 14, letterSpacing: 1.5)),
                        Row(
                          children: const [
                            Icon(Icons.star, color: AppTheme.accentColor, size: 16),
                            SizedBox(width: 4),
                            Text('VIP', style: TextStyle(color: AppTheme.accentColor, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }
    );
  }

  Widget _buildPointsStats() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF161C2A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.accentColor.withOpacity(0.15)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Column(
            children: [
              const Text('نقاط الولاء', style: TextStyle(color: Colors.white70, fontSize: 14)),
              const SizedBox(height: 8),
              Text('$_points', style: const TextStyle(color: AppTheme.accentColor, fontSize: 24, fontWeight: FontWeight.bold)),
            ],
          ),
          Container(height: 40, width: 1, color: Colors.grey.withOpacity(0.15)),
          Column(
            children: [
              const Text('الرصيد المتاح', style: TextStyle(color: Colors.white70, fontSize: 14)),
              const SizedBox(height: 8),
              Text('$_balance ج', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            ],
          ),
        ],
      ),
    );
  }

  void _redeemPoints(String title, int requiredPoints) {
    if (_points >= requiredPoints) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: const Color(0xFF161C2A),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: AppTheme.accentColor, width: 0.5)),
          title: const Text('تأكيد الاستبدال', style: TextStyle(color: Colors.white)),
          content: Text('هل تريد استبدال $requiredPoints نقطة مقابل: \n$title؟', style: const TextStyle(color: Colors.white70)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء', style: TextStyle(color: Colors.white70))),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _points -= requiredPoints;
                });
                Navigator.pop(context);
                _showSuccessAnimation(title);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accentColor, foregroundColor: Colors.black87),
              child: const Text('تأكيد'),
            ),
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('عذراً، نقاطك لا تكفي لهذا الامتياز ⚠️')));
    }
  }

  void _showSuccessAnimation(String title) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: const Color(0xFF161C2A),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.accentColor, width: 1.5),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.stars_rounded, color: AppTheme.accentColor, size: 80),
              const SizedBox(height: 24),
              const Text('مبروك!', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text('تم تفعيل امتياز: \n$title', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 16)),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accentColor, foregroundColor: Colors.black87),
                child: const Text('رائع!', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRewardItem(String title, String subtitle, IconData icon, int points) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF161C2A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: AppTheme.accentColor.withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(icon, color: AppTheme.accentColor),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12)),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () => _redeemPoints(title, points),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.accentColor,
              foregroundColor: Colors.black87,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
            child: const Text('استبدال', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
          ),
        ],
      ),
    );
  }

  Widget _buildRewardsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('امتيازات إيليت المتاحة', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        _buildRewardItem('ترقية مجانية لتنظيف فندقي', 'استبدل 3000 نقطة', Icons.cleaning_services, 3000),
        const SizedBox(height: 12),
        _buildRewardItem('خُصم 5% على التوثيق القانوني', 'استبدل 5000 نقطة', Icons.gavel, 5000),
        const SizedBox(height: 12),
        _buildRewardItem('توصيلة ليموزين للمطار مجانًا', 'استبدل 10000 نقطة', Icons.directions_car, 10000),
      ],
    );
  }
}
