import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../theme/app_theme.dart';
import '../services/data_service.dart';

class VerificationScreen extends StatefulWidget {
  const VerificationScreen({super.key});

  @override
  State<VerificationScreen> createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  List<Map<String, dynamic>> _verificationRequests = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRequests();
  }

  Future<void> _loadRequests() async {
    final prefs = await SharedPreferences.getInstance();
    List<String>? requests = prefs.getStringList('verification_requests');
    
    if (requests != null) {
      setState(() {
        _verificationRequests = requests.map((r) => jsonDecode(r) as Map<String, dynamic>).toList();
        _isLoading = false;
      });
    } else {
      // Add demo requests
      _verificationRequests = [
        {
          'id': '1',
          'userName': 'أحمد محمد',
          'userType': 'owner',
          'email': 'ahmed@example.com',
          'phone': '01012345678',
          'status': 'pending',
          'documents': ['بطاقة الرقم القومي', 'عقد ملكية'],
        },
        {
          'id': '2',
          'userName': 'سارة علي',
          'userType': 'tenant',
          'email': 'sara@example.com',
          'phone': '01098765432',
          'status': 'pending',
          'documents': ['بطاقة الرقم القومي'],
        },
      ];
      setState(() => _isLoading = false);
    }
  }

  Future<void> _updateStatus(int index, String status) async {
    setState(() {
      _verificationRequests[index]['status'] = status;
    });
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      'verification_requests',
      _verificationRequests.map((r) => jsonEncode(r)).toList(),
    );

    // Update user verification status if approved
    if (status == 'approved') {
      final userEmail = _verificationRequests[index]['email'];
      final userKey = 'user_$userEmail';
      final userJson = prefs.getString(userKey);
      
      if (userJson != null) {
        Map<String, dynamic> userData = jsonDecode(userJson);
        userData['isVerified'] = true;
        userData['verifiedAt'] = DateTime.now().toIso8601String();
        await prefs.setString(userKey, jsonEncode(userData));
      }

      // Add Notification
      await DataService.addNotification(
        'تم توثيق حسابك! 🎉', 
        'تهانينا ${_verificationRequests[index]['userName']}، لقد تم فحص مستنداتك وتوثيق حسابك بنجاح. يمكنك الآن التمتع بكافة مميزات كيو إيليت.'
      );
    } else if (status == 'rejected') {
      // Add Notification
      await DataService.addNotification(
        'تم رفض طلب التوثيق ❌', 
        'عذراً ${_verificationRequests[index]['userName']}، لم نتمكن من قبول مستندات التوثيق الخاصة بك. يرجى مراجعة البيانات والمحاولة مرة أخرى.'
      );
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(status == 'approved' ? 'تم توثيق الحساب ✅' : 'تم رفض التوثيق ❌'),
          backgroundColor: status == 'approved' ? Colors.green : Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('طلبات التوثيق')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _verificationRequests.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _verificationRequests.length,
                  itemBuilder: (context, index) => _buildRequestCard(_verificationRequests[index], index),
                ),
    );
  }

  Widget _buildRequestCard(Map<String, dynamic> request, int index) {
    String status = request['status'] ?? 'pending';
    Color statusColor = status == 'pending' ? Colors.orange : (status == 'approved' ? Colors.green : Colors.red);
    String statusText = status == 'pending' ? 'قيد المراجعة' : (status == 'approved' ? 'موثق' : 'مرفوض');
    IconData userIcon = request['userType'] == 'owner' ? Icons.business : Icons.person;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 5)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
                child: Icon(userIcon, color: AppTheme.primaryColor),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(request['userName'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    Text(
                      request['userType'] == 'owner' ? 'مالك' : 'مستأجر',
                      style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(statusText, style: TextStyle(color: statusColor, fontSize: 12, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const Divider(height: 24),
          _buildInfoRow(Icons.email, request['email']),
          _buildInfoRow(Icons.phone, request['phone']),
          const SizedBox(height: 12),
          const Text('المستندات المرفقة:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 8),
          ...(request['documents'] as List).map((doc) => Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              children: [
                const Icon(Icons.check_circle, size: 16, color: Colors.green),
                const SizedBox(width: 8),
                Text(doc, style: const TextStyle(fontSize: 12)),
              ],
            ),
          )),
          if (status == 'pending') ...[
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _updateStatus(index, 'rejected'),
                    style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                    child: const Text('رفض'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _updateStatus(index, 'approved'),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                    child: const Text('توثيق'),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 16, color: AppTheme.textSecondary),
          const SizedBox(width: 8),
          Text(text, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.verified_user, size: 80, color: Colors.grey[300]),
          const SizedBox(height: 16),
          const Text('لا توجد طلبات توثيق حالياً', style: TextStyle(color: AppTheme.textSecondary)),
        ],
      ),
    );
  }
}
