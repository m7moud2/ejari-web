import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'contract_view_screen.dart';
import 'package:intl/intl.dart';

class SuccessPaymentScreen extends StatefulWidget {
  final double amount;
  final String transactionId;
  final String paymentMethod; // New parameter

  const SuccessPaymentScreen({
    super.key,
    required this.amount,
    required this.transactionId,
    required this.paymentMethod,
  });

  @override
  State<SuccessPaymentScreen> createState() => _SuccessPaymentScreenState();
}

class _SuccessPaymentScreenState extends State<SuccessPaymentScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _scaleAnimation = CurvedAnimation(parent: _controller, curve: Curves.elasticOut);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              // Animated Success Icon
              ScaleTransition(
                scale: _scaleAnimation,
                child: Container(
                  padding: const EdgeInsets.all(30),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.check_circle,
                    color: Colors.green,
                    size: 80,
                  ),
                ),
              ),
              const SizedBox(height: 32),
              
              // Success Text
              const Text(
                'تم الدفع بنجاح!',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.secondaryColor,
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'تم تأكيد عملية الدفع وحجز الوحدة بنجاح.\nشكراً لاستخدامك كيو.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: AppTheme.textSecondary,
                  height: 1.5,
                ),
              ),
              
              const SizedBox(height: 48),
              
              // Transaction Details Card
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.grey[100]!),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 20, offset: const Offset(0, 10))],
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.verified_user_rounded, color: AppTheme.primaryColor, size: 16),
                        const SizedBox(width: 8),
                        const Text('إيصال ديجيتال موثق - كيو إيليت', style: TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const Divider(height: 32),
                    _buildDetailRow('المبلغ الإجمالي', '${widget.amount.toStringAsFixed(0)} ج.م', isBold: true),
                    const SizedBox(height: 16),
                    _buildDetailRow('رقم العملية', widget.transactionId),
                    const SizedBox(height: 12),
                    _buildDetailRow('التاريخ والوقت', DateFormat('yyyy/MM/dd - hh:mm a').format(DateTime.now())),
                    const SizedBox(height: 12),
                    _buildDetailRow('وسيلة الدفع', _getPaymentMethodName(widget.paymentMethod)),
                    const SizedBox(height: 12),
                    _buildDetailRow('الحساب الوجهة', '01069813210 (محفظة/InstaPay)'),
                    const Divider(height: 32),
                    const Text(
                      'سيصلك إشعار فور مراجعة المالك للطلب. يمكنك متابعة حالة الحجز من "حجوزاتي".',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 11, color: Colors.grey, height: 1.4),
                    ),
                  ],
                ),
              ),
              
              const Spacer(),
              
              // Actions
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        // Create a summary for the receipt/contract view
                        final mockBooking = {
                          'title': 'حجز عقار - معاملة ${widget.transactionId}',
                          'price': widget.amount,
                          'tenantName': 'مستخدم إيليت',
                          'ownerName': 'المالك المعتمد',
                          'startDate': DateTime.now().toString(),
                          'endDate': DateTime.now().add(const Duration(days: 365)).toString(),
                        };
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ContractViewScreen(bookingDetails: mockBooking),
                          ),
                        );
                      },
                      icon: const Icon(Icons.description_outlined),
                      label: const Text('عرض العقد'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        side: const BorderSide(color: AppTheme.primaryColor),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        // Go back to home (pop until first)
                        Navigator.of(context).popUntil((route) => route.isFirst);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryColor,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: const Text('الرئيسية', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: AppTheme.textSecondary,
            fontSize: 14,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: isBold ? Colors.black : Colors.black87,
            fontWeight: isBold ? FontWeight.bold : FontWeight.w500,
            fontSize: isBold ? 18 : 14,
          ),
        ),
      ],
    );
  }

  String _getPaymentMethodName(String method) {
    switch (method) {
      case 'wallet': return 'محفظة كيو';
      case 'card': return 'بطاقة ائتمان / خصم';
      case 'fawry': return 'فوري (Fawry)';
      case 'valu': return 'تقسيط (Valu)';
      default: return method;
    }
  }
}
