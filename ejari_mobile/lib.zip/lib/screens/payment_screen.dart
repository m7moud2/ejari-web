import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/data_service.dart';
import '../utils/image_utils.dart';
import '../widgets/elite_image.dart';
import 'package:image_picker/image_picker.dart';
import 'success_screen.dart';

class PaymentScreen extends StatefulWidget {
  final String itemType; 
  final Map<String, dynamic> itemData;
  final double amount;

  const PaymentScreen({
    super.key,
    required this.itemType,
    required this.itemData,
    required this.amount,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String _selectedCategory = 'cards'; 
  String _selectedSubMethod = 'visa';
  bool _isProcessing = false;
  String? _receiptPath;
  
  final List<Map<String, dynamic>> _bnplMethods = [
    {'id': 'valu', 'name': 'ValU', 'color': Colors.orange, 'icon': Icons.flash_on_rounded, 'logo': 'V'},
    {'id': 'halan', 'name': 'Halan', 'color': Colors.redAccent, 'icon': Icons.bolt_rounded, 'logo': 'H'},
    {'id': 'migo', 'name': 'Migo', 'color': Colors.blue, 'icon': Icons.shopping_bag_rounded, 'logo': 'M'},
    {'id': 'mylo', 'name': 'Mylo', 'color': Colors.purple, 'icon': Icons.favorite_rounded, 'logo': 'My'},
    {'id': 'souhoola', 'name': 'Souhoola', 'color': Colors.teal, 'icon': Icons.calendar_month_rounded, 'logo': 'S'},
  ];

  final List<Map<String, dynamic>> _walletMethods = [
    {'id': 'vodafone', 'name': 'Vodafone Cash', 'color': Colors.red, 'icon': Icons.phone_android, 'logo': 'VC'},
    {'id': 'instapay', 'name': 'InstaPay', 'color': Colors.blue, 'icon': Icons.send_rounded, 'logo': 'IP'},
    {'id': 'fawry', 'name': 'Fawry', 'color': Colors.orange, 'icon': Icons.storefront_rounded, 'logo': 'F'},
    {'id': 'orange', 'name': 'Orange Cash', 'color': Colors.orangeAccent, 'icon': Icons.phone_iphone, 'logo': 'OC'},
  ];
  
  final _cardNumberController = TextEditingController();
  final _expiryController = TextEditingController();
  final _cvvController = TextEditingController();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();

  @override
  void dispose() {
    _cardNumberController.dispose();
    _expiryController.dispose();
    _cvvController.dispose();
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  bool _validateFields() {
    if (_selectedCategory == 'cards') {
      return _cardNumberController.text.length >= 16 && _expiryController.text.contains('/') && _cvvController.text.length >= 3;
    } else if (_selectedCategory == 'bnpl' || _selectedCategory == 'wallets') {
      return _phoneController.text.length >= 10;
    } else if (_selectedCategory == 'manual') {
      return _receiptPath != null;
    }
    return true;
  }

  Future<void> _processPayment() async {
    if (!_validateFields()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('يرجى إكمال كافة البيانات المطلوبة لإتمام الدفع الآمن'),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() => _isProcessing = true);
    await Future.delayed(const Duration(seconds: 4));

    if (widget.itemType == 'booking') {
        await DataService.payForBooking(widget.itemData['id']);
    }
    
    if (!mounted) return;
    setState(() => _isProcessing = false);
    
    final successMessage = _selectedCategory == 'manual'
        ? 'لقد تم إرسال إيصال الدفع للمراجعة. سيتم تفعيل الخدمة فور التأكد من التحويل.'
        : 'لقد تم دفع ${widget.amount} ج.م بنجاح عبر ${_getFriendlyMethodName()}';

    _showSuccessVibe(successMessage);
  }

  void _showSuccessVibe(String message) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SuccessScreen(
          title: 'تم الدفع بنجاح! 🎉',
          message: message,
          onContinue: () {
            Navigator.pop(context); // Pop Success
            Navigator.pop(context, true); // Pop Payment
          },
        ),
      ),
    );
  }

  String _getFriendlyMethodName() {
    if (_selectedCategory == 'cards') return 'البطاقة البنكية';
    if (_selectedCategory == 'wallets') return 'المحفظة الإلكترونية';
    if (_selectedCategory == 'bnpl') return _selectedSubMethod.toUpperCase();
    return 'بوابة الدفع';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('إتمام الحجز الآمن', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Colors.white)),
        backgroundColor: AppTheme.secondaryColor,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.only(bottom: 120),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildEliteSummary(),
                const SizedBox(height: 20),
                _buildStepHeader('1', 'اختر طريقة الدفع المفضلة'),
                _buildCategoryGrid(),
                const SizedBox(height: 20),
                _buildStepHeader('2', 'بيانات الدفع'),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _buildMethodSpecificForm(),
                ),
              ],
            ),
          ),
          _buildBottomPayBar(),
          if (_isProcessing) _buildProcessingOverlay(),
        ],
      ),
    );
  }

  Widget _buildStepHeader(String step, String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: const BoxDecoration(color: AppTheme.primaryColor, shape: BoxShape.circle),
            child: Center(child: Text(step, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold))),
          ),
          const SizedBox(width: 10),
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.secondaryColor)),
        ],
      ),
    );
  }

  Widget _buildEliteSummary() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: const BoxDecoration(
        color: AppTheme.secondaryColor,
        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(32), bottomRight: Radius.circular(32)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.receipt_long_rounded, color: Colors.white),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_getItemTitle(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    Text('معرف الحجز: #EJ-${widget.itemData['id'] ?? '882'}', style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 12)),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('${widget.amount} ج.م', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                  const Text('الإجمالي شامل الضريبة', style: TextStyle(color: Colors.greenAccent, fontSize: 10, fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 2.2,
        children: [
          _buildCatCard('cards', 'بطاقة بنكية', Icons.credit_card_rounded),
          _buildCatCard('bnpl', 'تقسيط مباشر', Icons.timer_outlined),
          _buildCatCard('wallets', 'محافظ كاش', Icons.account_balance_wallet_rounded),
          _buildCatCard('manual', 'إيداع بنكي', Icons.account_balance_rounded),
        ],
      ),
    );
  }

  Widget _buildCatCard(String id, String label, IconData icon) {
    final isSelected = _selectedCategory == id;
    return GestureDetector(
      onTap: () => setState(() {
        _selectedCategory = id;
        if (id == 'bnpl') _selectedSubMethod = 'valu';
        if (id == 'wallets') _selectedSubMethod = 'vodafone';
      }),
      child: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryColor : (Theme.of(context).cardTheme.color ?? Colors.white),
          borderRadius: BorderRadius.circular(16),
          boxShadow: isSelected ? [BoxShadow(color: AppTheme.primaryColor.withOpacity(0.3), blurRadius: 10)] : [],
          border: Border.all(color: isSelected ? AppTheme.primaryColor : (Theme.of(context).brightness == Brightness.light ? Colors.grey[200]! : Colors.grey[800]!)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: isSelected ? Colors.white : Colors.grey, size: 20),
            const SizedBox(width: 8),
            Text(
              label, 
              style: TextStyle(
                color: isSelected ? Colors.white : (Theme.of(context).brightness == Brightness.light ? Colors.black87 : Colors.grey[300]), 
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal
              )
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMethodSpecificForm() {
    switch (_selectedCategory) {
      case 'cards':
        return _buildCardsForm();
      case 'bnpl':
        return _buildSubMethodsGrid(_bnplMethods);
      case 'wallets':
        return _buildSubMethodsGrid(_walletMethods);
      case 'manual':
        return _buildManualForm();
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildCardsForm() {
    return Column(
      children: [
        _buildInputField(_cardNumberController, 'رقم البطاقة', Icons.credit_card, 'xxxx xxxx xxxx xxxx'),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _buildInputField(_expiryController, 'الانتهاء', Icons.calendar_today, 'MM/YY')),
            const SizedBox(width: 12),
            Expanded(child: _buildInputField(_cvvController, 'CVV', Icons.lock_outline, 'xxx')),
          ],
        ),
        const SizedBox(height: 12),
        _buildInputField(_nameController, 'الاسم بالكامل', Icons.person_outline, 'كما هو في البطاقة'),
        const SizedBox(height: 15),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.shield_outlined, color: Colors.green, size: 14),
            const SizedBox(width: 5),
            Text('مشفر بواسطة SSL ومعتمد من البنك المركزي', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
          ],
        ),
      ],
    );
  }

  Widget _buildSubMethodsGrid(List<Map<String, dynamic>> methods) {
    return Column(
      children: [
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: methods.map((m) => _buildSubMethodItem(m)).toList(),
        ),
        const SizedBox(height: 20),
        _buildInputField(_phoneController, 'رقم الموبايل المسجل', Icons.phone_android, '01x xxxx xxxx'),
      ],
    );
  }

  Widget _buildSubMethodItem(Map<String, dynamic> m) {
    final isSelected = _selectedSubMethod == m['id'];
    return GestureDetector(
      onTap: () => setState(() => _selectedSubMethod = m['id']),
      child: Container(
        width: 100,
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color ?? Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isSelected ? m['color'] : (Theme.of(context).brightness == Brightness.light ? Colors.grey.shade200 : Colors.grey.shade800), width: isSelected ? 2 : 1),
        ),
        child: Column(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: m['color'].withOpacity(0.1), shape: BoxShape.circle),
              child: Center(child: Text(m['logo'], style: TextStyle(color: m['color'], fontWeight: FontWeight.bold, fontSize: 16))),
            ),
            const SizedBox(height: 8),
            Text(m['name'], style: TextStyle(fontSize: 11, fontWeight: isSelected ? FontWeight.bold : FontWeight.normal, color: Theme.of(context).textTheme.bodyMedium?.color)),
          ],
        ),
      ),
    );
  }

  Widget _buildManualForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Theme.of(context).brightness == Brightness.light ? Colors.blue.shade50 : const Color(0xFF1E293B), borderRadius: BorderRadius.circular(16)),
          child: Column(
            children: [
              Text('قم بالتحويل لأي من الحسابات التالية وارفع الإيصال:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.bodyLarge?.color)),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('فودافون كاش:', style: TextStyle(color: Theme.of(context).textTheme.bodyMedium?.color)), const Text('01069813210', style: TextStyle(fontWeight: FontWeight.bold))]),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('InstaPay IPA:', style: TextStyle(color: Theme.of(context).textTheme.bodyMedium?.color)), const Text('keyo@instapay', style: TextStyle(fontWeight: FontWeight.bold))]),
            ],
          ),
        ),
        const SizedBox(height: 20),
        GestureDetector(
          onTap: () async {
            final xFile = await ImageUtils.pickAndCompress(source: ImageSource.gallery);
            if (xFile != null) setState(() => _receiptPath = xFile.path);
          },
          child: Container(
            height: 120,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Theme.of(context).cardTheme.color ?? Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _receiptPath == null ? (Theme.of(context).brightness == Brightness.light ? Colors.grey.shade300 : Colors.grey.shade800) : Colors.green),
              image: _receiptPath != null ? EliteImage.decoration(path: _receiptPath!, isLocalFile: true) : null,
            ),
            child: _receiptPath == null ? const Center(child: Text('اضغط لرفع صورة الإيصال 📸', style: TextStyle(color: Colors.grey))) : null,
          ),
        ),
      ],
    );
  }

  Widget _buildInputField(TextEditingController controller, String label, IconData icon, String hint) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color ?? Colors.white, 
        borderRadius: BorderRadius.circular(16), 
        border: Border.all(color: Theme.of(context).brightness == Brightness.light ? Colors.grey.shade200 : Colors.grey.shade800)
      ),
      child: TextField(
        controller: controller,
        style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Theme.of(context).brightness == Brightness.light ? Colors.grey[700] : Colors.grey[400]),
          hintText: hint,
          hintStyle: TextStyle(color: Theme.of(context).brightness == Brightness.light ? Colors.grey[400] : Colors.grey[600]),
          prefixIcon: Icon(icon, color: AppTheme.secondaryColor, size: 20),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),
    );
  }

  Widget _buildBottomPayBar() {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color ?? Colors.white, 
          boxShadow: [BoxShadow(color: Theme.of(context).brightness == Brightness.light ? Colors.black.withOpacity(0.05) : Colors.black45, blurRadius: 20, offset: const Offset(0, -5))]
        ),
        child: SafeArea(
          child: ElevatedButton(
            onPressed: _processPayment,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            child: Text('تأكيد الدفع الآمن (${widget.amount} ج.م)', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
          ),
        ),
      ),
    );
  }

  Widget _buildProcessingOverlay() {
    return Container(
      color: AppTheme.secondaryColor.withOpacity(0.95),
      child: const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: Colors.white),
            SizedBox(height: 20),
            Text('جاري معالجة الدفع بأمان...', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  String _getItemTitle() {
    return widget.itemData['title'] ?? widget.itemData['name'] ?? 'وحدة كيو';
  }
}
