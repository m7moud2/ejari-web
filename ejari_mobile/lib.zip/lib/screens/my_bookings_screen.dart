import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/data_service.dart';
import 'package:intl/intl.dart';
import 'contract_view_screen.dart';
import 'payment_screen.dart';
import 'chat_details_screen.dart';

class MyBookingsScreen extends StatefulWidget {
  const MyBookingsScreen({super.key});

  @override
  State<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class _MyBookingsScreenState extends State<MyBookingsScreen> {
  List<Map<String, dynamic>> _bookings = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadBookings();
  }

  Future<void> _loadBookings() async {
    final bookings = await DataService.getBookings();
    setState(() {
      _bookings = bookings;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حجوزاتي')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _bookings.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _bookings.length,
                  itemBuilder: (context, index) {
                    final booking = _bookings[index];
                    return _buildBookingCard(booking);
                  },
                ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.calendar_today_outlined, size: 80, color: Colors.grey[300]),
          const SizedBox(height: 16),
          const Text(
            'لا توجد حجوزات حالياً',
            style: TextStyle(fontSize: 18, color: AppTheme.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _buildBookingCard(Map<String, dynamic> booking) {
    String status = booking['status'] ?? 'pending';
    Color statusColor;
    String statusText;
    
    switch (status) {
      case 'pending':
        statusColor = Colors.orange;
        statusText = 'قيد الانتظار';
        break;
      case 'approved': // Was accepted
        statusColor = Colors.green;
        statusText = 'تمت الموافقة';
        break;
      case 'rejected':
        statusColor = Colors.red;
        statusText = 'مرفوض';
        break;
      case 'active':
      case 'paid':
        statusColor = Colors.blue;
        statusText = 'نشط / مدفوع';
        break;
      case 'completed':
        statusColor = Colors.grey;
        statusText = 'مكتمل';
        break;
      default:
        statusColor = Colors.grey;
        statusText = status;
    }
    
    // Format date
    String dateStr = '';
    if (booking['startDate'] != null) {
      try {
        DateTime date = DateTime.parse(booking['startDate']);
        dateStr = DateFormat('yyyy-MM-dd').format(date);
      } catch (e) {
        dateStr = booking['startDate'];
      }
    } else if (booking['requestDate'] != null) {
       try {
        DateTime date = DateTime.parse(booking['requestDate']);
        dateStr = DateFormat('yyyy-MM-dd').format(date);
      } catch (e) {
        dateStr = 'اليوم';
      }
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color ?? Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Theme.of(context).brightness == Brightness.light ? Colors.black12 : Colors.transparent, blurRadius: 10, offset: const Offset(0, 5))],
      ),
      child: Column(
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  booking['image'] ?? 'assets/images/home1.jpg',
                  width: 80,
                  height: 80,
                  fit: BoxFit.cover,
                  errorBuilder: (c, e, s) => Container(width: 80, height: 80, color: Colors.grey[200], child: const Icon(Icons.home, color: Colors.grey)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            booking['title'] ?? booking['service'] ?? 'طلب خدمة',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: statusColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            statusText,
                            style: TextStyle(color: statusColor, fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (booking['duration'] != null)
                      Text('المدة: ${booking['duration']}', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                    Text(dateStr, style: TextStyle(color: Theme.of(context).textTheme.bodySmall?.color ?? AppTheme.textSecondary, fontSize: 12)),
                    const SizedBox(height: 4),
                    Text('${booking['price']} ج.م', style: const TextStyle(color: AppTheme.primaryColor, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ],
          ),
          
          // Action Buttons
          if (status == 'approved') ...[
            const SizedBox(height: 16),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  // Navigate to real Payment Screen
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PaymentScreen(
                        itemType: 'booking',
                        itemData: booking,
                        amount: double.tryParse(booking['price'].toString()) ?? 0.0,
                      ),
                    ),
                  );

                  // If payment was successful (returns true)
                  if (result == true) {
                    _loadBookings(); // Refresh UI to show 'paid' status
                  }
                },
                icon: const Icon(Icons.payment, size: 18),
                label: const Text('ادفع الآن واصدر العقد'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  elevation: 0,
                ),
              ),
            ),
          ],
          
          if (status == 'paid' || status == 'active') ...[
             const SizedBox(height: 16),
             Row(
               children: [
                 Expanded(
                   child: OutlinedButton.icon(
                    onPressed: () {
                         Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ContractViewScreen(bookingDetails: booking),
                          ),
                        );
                    },
                    icon: const Icon(Icons.description_outlined, size: 18),
                    label: const Text('عقدي الإلكتروني'),
                   ),
                 ),
                 const SizedBox(width: 8),
                 Expanded(
                   child: ElevatedButton.icon(
                    onPressed: () {
                       Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ChatDetailsScreen(userName: 'احمد محمد (المالك)'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.chat_bubble_outline, size: 18),
                    label: const Text('محادثة المالك'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                    ),
                   ),
                 ),
               ],
             )
          ]
        ],
      ),
    );
  }
}
