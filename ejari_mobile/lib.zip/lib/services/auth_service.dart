import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/api_client.dart';

class AuthService {
  static const String _usersListKey = 'users_list'; // stores all registered emails
  static const String _currentUserKey = 'current_user_email'; // tracks logged-in user
  static const String _userRoleKey = 'current_user_role'; // 'owner', 'tenant', or 'provider'

  // Generate key for storing user data
  static String _getUserDataKey(String email) => 'user_$email';

  // SignUp - Save new user account
  static Future<bool> signUp(Map<String, dynamic> userData) async {
    final prefs = await SharedPreferences.getInstance();
    final email = userData['email'] as String;

    try {
      // 1. Try backend register API
      final registerData = {
        'name': userData['name'],
        'email': email,
        'password': userData['password'],
        'role': userData['type'] ?? 'tenant',
        'phone': userData['phone'] ?? '',
        'address': userData['address'] ?? 'القاهرة، مصر',
      };
      
      final response = await ApiClient.post('/auth/register', registerData);
      
      if (response.statusCode == 200 || response.statusCode == 201) {
        final decoded = jsonDecode(utf8.decode(response.bodyBytes));
        if (decoded['success'] == true) {
          final token = decoded['token'] as String;
          await ApiClient.saveToken(token);
          
          // Fetch complete profile details from server
          final profileResponse = await ApiClient.get('/auth/me');
          if (profileResponse.statusCode == 200) {
            final profileDecoded = jsonDecode(utf8.decode(profileResponse.bodyBytes));
            if (profileDecoded['success'] == true) {
              final serverUser = profileDecoded['data'] as Map<String, dynamic>;
              // Map role to type for compatibility
              serverUser['type'] = serverUser['role'] ?? 'tenant';
              
              // Save user data locally
              await prefs.setString(_getUserDataKey(email), jsonEncode(serverUser));
              
              // Add to local list of users
              final List<String> users = prefs.getStringList(_usersListKey) ?? [];
              if (!users.contains(email)) {
                users.add(email);
                await prefs.setStringList(_usersListKey, users);
              }
              
              // Set session
              await prefs.setString(_currentUserKey, email);
              await prefs.setString(_userRoleKey, serverUser['type']);
              return true;
            }
          }
        }
      }
    } catch (e) {
      debugPrint('SignUp API Error: $e. Falling back to offline mode.');
    }

    // 2. Fallback to Local SharedPreferences SignUp
    final List<String> users = prefs.getStringList(_usersListKey) ?? [];
    if (users.contains(email)) {
      return false; // User already exists
    }

    // Save user data with email-based key
    String userJson = jsonEncode(userData);
    await prefs.setString(_getUserDataKey(email), userJson);

    // Add email to users list
    users.add(email);
    await prefs.setStringList(_usersListKey, users);

    // Auto-login after signup
    await prefs.setString(_currentUserKey, email);
    await prefs.setString(_userRoleKey, userData['type'] ?? 'tenant');
    return true;
  }

  // Initialize Demo Accounts (Run once)
  static Future<void> initDemoAccounts() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> users = prefs.getStringList(_usersListKey) ?? [];
    
    // Create Owner Account
    if (!users.contains('owner@keyo.app')) {
      final ownerData = {
        'name': 'أحمد المالك',
        'email': 'owner@keyo.app',
        'password': 'owner123',
        'phone': '01000000001',
        'type': 'owner',
      };
      await signUp(ownerData);
    }

    // Create User Account
    if (!users.contains('user@keyo.app')) {
      final userData = {
        'name': 'محمد المستأجر',
        'email': 'user@keyo.app',
        'password': 'user123',
        'phone': '01000000002',
        'type': 'tenant',
      };
      await signUp(userData);
    }

    // Create Provider/Technician Account
    if (!users.contains('tech@keyo.app')) {
      final techData = {
        'name': 'المهندس هاني الصيانة',
        'email': 'tech@keyo.app',
        'password': 'tech123',
        'phone': '01000000003',
        'type': 'provider',
      };
      await signUp(techData);
    }

    // Create Admin Account (The Elite Control Tower)
    if (!users.contains('admin@keyo.app')) {
      final adminData = {
        'name': 'مدير النظام التنفيذي',
        'email': 'admin@keyo.app',
        'password': 'admin123',
        'phone': '01234567890',
        'type': 'admin',
      };
      await signUp(adminData);
    }
  }

  // Login with email and password
  static Future<Map<String, dynamic>?> login(String email, String password) async {
    final prefs = await SharedPreferences.getInstance();

    try {
      // 1. Try Backend Login API
      final response = await ApiClient.post('/auth/login', {
        'email': email,
        'password': password,
      });

      if (response.statusCode == 200) {
        final decoded = jsonDecode(utf8.decode(response.bodyBytes));
        if (decoded['success'] == true) {
          final token = decoded['token'] as String;
          await ApiClient.saveToken(token);

          // Get complete profile info
          final profileResponse = await ApiClient.get('/auth/me');
          if (profileResponse.statusCode == 200) {
            final profileDecoded = jsonDecode(utf8.decode(profileResponse.bodyBytes));
            if (profileDecoded['success'] == true) {
              final serverUser = profileDecoded['data'] as Map<String, dynamic>;
              serverUser['type'] = serverUser['role'] ?? 'tenant';
              
              // Save user details locally for quick access & offline caching
              await prefs.setString(_getUserDataKey(email), jsonEncode(serverUser));
              await prefs.setString(_currentUserKey, email);
              await prefs.setString(_userRoleKey, serverUser['type']);
              
              // Ensure email is in user list
              final List<String> users = prefs.getStringList(_usersListKey) ?? [];
              if (!users.contains(email)) {
                users.add(email);
                await prefs.setStringList(_usersListKey, users);
              }
              
              return serverUser;
            }
          }
        }
      }
    } catch (e) {
      debugPrint('Login API Error: $e. Trying local fallback.');
    }

    // 2. Fallback to Local Offline Login
    String? userJson = prefs.getString(_getUserDataKey(email));
    if (userJson != null) {
      Map<String, dynamic> userData = jsonDecode(userJson);
      
      // Check if user is blocked
      if (userData['isBlocked'] == true) {
        return {'error': 'blocked'};
      }

      // Verify password
      if (userData['password'] == password) {
        await prefs.setString(_currentUserKey, email);
        await prefs.setString(_userRoleKey, userData['type'] ?? 'tenant');
        return userData;
      }
    }
    return null; // User not found or password incorrect
  }

  // Get currently logged-in user
  static Future<Map<String, dynamic>?> getCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final currentEmail = prefs.getString(_currentUserKey);

    if (currentEmail != null && currentEmail.isNotEmpty) {
      // 1. Try to sync current user from server
      try {
        final token = await ApiClient.getToken();
        if (token != null && token.isNotEmpty) {
          final response = await ApiClient.get('/auth/me');
          if (response.statusCode == 200) {
            final decoded = jsonDecode(utf8.decode(response.bodyBytes));
            if (decoded['success'] == true) {
              final serverUser = decoded['data'] as Map<String, dynamic>;
              serverUser['type'] = serverUser['role'] ?? 'tenant';
              
              // Update cache
              await prefs.setString(_getUserDataKey(currentEmail), jsonEncode(serverUser));
              await prefs.setString(_userRoleKey, serverUser['type']);
              return serverUser;
            }
          }
        }
      } catch (e) {
        debugPrint('GetCurrentUser API Error: $e. Returning cached local data.');
      }

      // 2. Return cached user details
      String? userJson = prefs.getString(_getUserDataKey(currentEmail));
      if (userJson != null) {
        return jsonDecode(userJson);
      }
    }
    return null;
  }

  // Logout
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    
    // Optional: Call logout on API
    try {
      await ApiClient.get('/auth/logout');
    } catch (_) {}

    await ApiClient.clearToken();
    await prefs.setString(_currentUserKey, '');
    await prefs.remove(_userRoleKey);
  }

  // Check if user is logged in
  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    final currentEmail = prefs.getString(_currentUserKey);
    return currentEmail != null && currentEmail.isNotEmpty;
  }

  // Role Management
  static Future<String> getUserRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_userRoleKey) ?? 'tenant';
  }

  static Future<void> setUserRole(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_userRoleKey, role);
  }

  // Get all registered users (for admin/debugging)
  static Future<List<Map<String, dynamic>>> getAllUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> users = prefs.getStringList(_usersListKey) ?? [];
    final List<Map<String, dynamic>> allUsers = [];

    for (String email in users) {
      String? userJson = prefs.getString(_getUserDataKey(email));
      if (userJson != null) {
        allUsers.add(jsonDecode(userJson));
      }
    }
    return allUsers;
  }

  // Delete user account
  static Future<bool> deleteAccount(String email) async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> users = prefs.getStringList(_usersListKey) ?? [];

    if (users.contains(email)) {
      users.remove(email);
      await prefs.setStringList(_usersListKey, users);
      await prefs.remove(_getUserDataKey(email));

      // If this was the logged-in user, logout
      if (prefs.getString(_currentUserKey) == email) {
        await logout();
      }
      return true;
    }
    return false;
  }

  // Update user profile
  static Future<bool> updateProfile(Map<String, dynamic> updatedData) async {
    final prefs = await SharedPreferences.getInstance();
    final email = updatedData['email'] as String;
    
    try {
      final response = await ApiClient.put('/auth/updatedetails', {
        'name': updatedData['name'],
        'email': updatedData['email'],
        'phone': updatedData['phone'],
      });

      if (response.statusCode == 200) {
        final decoded = jsonDecode(utf8.decode(response.bodyBytes));
        if (decoded['success'] == true) {
          final serverUser = decoded['data'] as Map<String, dynamic>;
          serverUser['type'] = serverUser['role'] ?? 'tenant';
          await prefs.setString(_getUserDataKey(email), jsonEncode(serverUser));
          return true;
        }
      }
    } catch (e) {
      debugPrint('UpdateProfile API Error: $e. Saving locally.');
    }

    // Fallback to local update
    String? userJson = prefs.getString(_getUserDataKey(email));
    if (userJson != null) {
      Map<String, dynamic> currentData = jsonDecode(userJson);
      currentData.addAll(updatedData);
      await prefs.setString(_getUserDataKey(email), jsonEncode(currentData));
      return true;
    }
    return false;
  }

  // Admin: Update user role
  static Future<bool> updateUserRole(String email, String newRole) async {
    final prefs = await SharedPreferences.getInstance();
    String? userJson = prefs.getString(_getUserDataKey(email));
    if (userJson != null) {
      Map<String, dynamic> userData = jsonDecode(userJson);
      userData['type'] = newRole;
      await prefs.setString(_getUserDataKey(email), jsonEncode(userData));
      return true;
    }
    return false;
  }

  // Admin: Toggle user block status
  static Future<bool> toggleUserBlock(String email) async {
    final prefs = await SharedPreferences.getInstance();
    String? userJson = prefs.getString(_getUserDataKey(email));
    if (userJson != null) {
      Map<String, dynamic> userData = jsonDecode(userJson);
      bool currentStatus = userData['isBlocked'] ?? false;
      userData['isBlocked'] = !currentStatus;
      await prefs.setString(_getUserDataKey(email), jsonEncode(userData));
      return true;
    }
    return false;
  }

  // Clear all data (for testing/reset)
  static Future<void> clearAllData() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> users = prefs.getStringList(_usersListKey) ?? [];
    for (String email in users) {
      await prefs.remove(_getUserDataKey(email));
    }
    await prefs.remove(_usersListKey);
    await prefs.remove(_currentUserKey);
    await ApiClient.clearToken();
  }
}
