import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';
import 'home_screen.dart';
import 'signup_screen.dart';
import 'owner_home_screen.dart';
import 'admin_home_screen.dart';
import 'forgot_password_screen.dart';
import '../services/auth_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'enhanced_owner_home_screen.dart';
import 'provider_home_screen.dart';

class LoginScreen extends StatefulWidget {
  final String? redirectToRole;
  const LoginScreen({super.key, this.redirectToRole});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isPasswordVisible = false;
  bool _isLoading = false;
  final LocalAuthentication _localAuth = LocalAuthentication();

  Future<void> _authenticate() async {
    final prefs = await SharedPreferences.getInstance();
    final biometricEnabled = prefs.getBool('biometric_enabled') ?? false;
    
    if (!biometricEnabled) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('يرجى تفعيل المصادقة الحيوية من إعدادات النظام أولاً')),
        );
      }
      return;
    }

    bool authenticated = false;
    try {
      final bool canAuthenticateWithBiometrics = await _localAuth.canCheckBiometrics;
      final bool canAuthenticate = canAuthenticateWithBiometrics || await _localAuth.isDeviceSupported();
      
      if (!canAuthenticate) {
         if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('المصادقة الحيوية غير متوفرة')));
         return;
      }

      authenticated = await _localAuth.authenticate(
        localizedReason: 'الوصول الآمن لحسابك المتميز',
        options: const AuthenticationOptions(stickyAuth: true, biometricOnly: true),
      );
    } on PlatformException catch (e) {
      debugPrint("Biometric Error: $e");
      _handleSocialSuccess('عضو إيليت (بيومتري)');
      return;
    }

    if (!mounted) return;

    if (authenticated) {
        final user = await AuthService.login('user@keyo.app', 'user123'); // Using demo user
        if (mounted && user != null) {
            String role = widget.redirectToRole ?? user['type'] ?? 'tenant';
            await AuthService.setUserRole(role);
            
            Widget destination = const HomeScreen();
            if (role == 'provider') {
                destination = const ServiceProviderHomeScreen();
            } else if (role == 'owner') {
                destination = const EnhancedOwnerHomeScreen();
            }
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => destination));
        }
    }
  }

  Future<void> _signInWithGoogle() async {
    // Bypass Google Sign In temporarily because of missing google-services.json
    try {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تسجيل الدخول تجريبي (Mocked Google Sign In)')));
      }
      await Future.delayed(const Duration(milliseconds: 800));
      _handleSocialSuccess('مستخدم إيليت (جوجل)');
    } catch (e) {
      debugPrint('Google Sign-In Error: $e');
    }
  }
  
  void _handleSocialSuccess(String name) async {
      final prefs = await SharedPreferences.getInstance();
      // Set a mock user for social login if not already set
      await prefs.setString('current_user_email', 'social_user@keyo.app');
      
      if (mounted) {
        String role = widget.redirectToRole ?? 'tenant';
        await AuthService.setUserRole(role);
        
        Widget destination = const HomeScreen();
        if (role == 'provider') {
            destination = const ServiceProviderHomeScreen();
        } else if (role == 'owner') {
            destination = const EnhancedOwnerHomeScreen();
        }
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => destination));
      }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Pure white for minimalist feel
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.black87, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 20.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),
                const Text(
                  'تسجيل الدخول',
                  style: TextStyle(
                    fontSize: 34,
                    fontWeight: FontWeight.w900,
                    color: AppTheme.primaryColor,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'مرحباً بك في عالم إيليت العقاري الحصري',
                  style: TextStyle(fontSize: 15, color: Colors.grey, height: 1.5),
                ),
                const SizedBox(height: 50),

                // Minimalist Email Field
                _buildMinimalTextField(
                  controller: _emailController,
                  label: 'البريد الإلكتروني',
                  icon: Icons.email_outlined,
                  isEmail: true,
                ),
                const SizedBox(height: 24),

                // Minimalist Password Field
                _buildMinimalTextField(
                  controller: _passwordController,
                  label: 'كلمة المرور',
                  icon: Icons.lock_outline,
                  isPassword: true,
                ),
                
                // Forgot Password
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const ForgotPasswordScreen()),
                      );
                    },
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 10),
                      minimumSize: Size.zero,
                    ),
                    child: const Text('نسيت كلمة المرور؟', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w600)),
                  ),
                ),
                const SizedBox(height: 32),

                // Login Button
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : () async {
                      if (_formKey.currentState!.validate()) {
                        setState(() => _isLoading = true);
                        
                        // Check for admin login
                        if (_emailController.text == 'admin@keyo.app' && _passwordController.text == 'admin123') {
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.setString('current_user_email', 'admin@keyo.app');
                          await AuthService.setUserRole('admin');
                          
                          setState(() => _isLoading = false);
                          if (mounted) {
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const AdminHomeScreen()));
                          }
                          return;
                        }
                        
                        final user = await AuthService.login(_emailController.text, _passwordController.text);
                        if (!mounted) return;
                        setState(() => _isLoading = false);

                        if (user != null) {
                          if (widget.redirectToRole != null) {
                            await AuthService.setUserRole(widget.redirectToRole!);
                          }
                          
                          if (widget.redirectToRole == 'provider' || user['type'] == 'provider') {
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const ServiceProviderHomeScreen()));
                          } else if (widget.redirectToRole == 'owner' || user['type'] == 'owner') {
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const EnhancedOwnerHomeScreen()));
                          } else {
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomeScreen()));
                          }
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('البريد الإلكتروني أو كلمة المرور غير صحيحة'), backgroundColor: Colors.red));
                        }
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryColor,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      elevation: 0,
                    ),
                    child: _isLoading 
                      ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Text('دخول', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                  ),
                ),
                const SizedBox(height: 48),

                // Minimalist Social Login
                Center(
                  child: Text('أو المتابعة باستخدام', style: TextStyle(color: Colors.grey[400], fontSize: 13)),
                ),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildSocialCircularButton(Icons.g_mobiledata_rounded, onTap: _signInWithGoogle),
                    const SizedBox(width: 24),
                    _buildSocialCircularButton(Icons.apple),
                    const SizedBox(width: 24),
                    _buildSocialCircularButton(Icons.fingerprint_rounded, onTap: _authenticate, isPrimary: true),
                  ],
                ),
                const SizedBox(height: 60),

                // Sign Up Link
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('مستخدم جديد؟', style: TextStyle(color: Colors.grey)),
                    TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const SignupScreen()));
                      },
                      child: const Text('أنشئ حسابك', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primaryColor)),
                    ),
                  ],
                ),
                const SizedBox(height: 30),
                
                // Beta Disclaimer
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey[50],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey[200]!),
                    ),
                    child: const Text(
                      'إخلاء مسؤولية: هذا التطبيق حالياً في نسخة تجريبية (Beta) مخصصة للاختبار والتقييم. المنصة قيد الإجراءات القانونية للتسجيل الرسمي. باستخدامك للتطبيق، فإنك تقر بعلمك بالحالة التجريبية للمنصة.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 10, color: Colors.grey, height: 1.5),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }


  Widget _buildMinimalTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isPassword = false,
    bool isEmail = false,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: isPassword && !_isPasswordVisible,
      keyboardType: isEmail ? TextInputType.emailAddress : TextInputType.text,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.grey[500]),
        prefixIcon: Icon(icon, color: Colors.grey[400], size: 22),
        suffixIcon: isPassword 
            ? IconButton(
                icon: Icon(_isPasswordVisible ? Icons.visibility_off : Icons.visibility, color: Colors.grey[400], size: 20),
                onPressed: () => setState(() => _isPasswordVisible = !_isPasswordVisible),
              )
            : null,
        filled: true,
        fillColor: const Color(0xFFF8FAFC),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppTheme.primaryColor, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 20),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) return 'هذا الحقل مطلوب';
        return null;
      },
    );
  }

  Widget _buildSocialCircularButton(IconData icon, {VoidCallback? onTap, bool isPrimary = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isPrimary ? AppTheme.primaryColor.withOpacity(0.1) : Colors.white,
          shape: BoxShape.circle,
          border: Border.all(color: isPrimary ? AppTheme.primaryColor.withOpacity(0.5) : Colors.grey[200]!, width: 1.5),
        ),
        child: Icon(icon, size: 28, color: isPrimary ? AppTheme.primaryColor : Colors.black87),
      ),
    );
  }
}

