import 'package:flutter/material.dart';
import '../services/data_service.dart';
import '../theme/app_theme.dart';
import 'property_details_screen.dart';

class ForSaleScreen extends StatefulWidget {
  const ForSaleScreen({super.key});

  @override
  State<ForSaleScreen> createState() => _ForSaleScreenState();
}

class _ForSaleScreenState extends State<ForSaleScreen> {
  List<Map<String, dynamic>> _saleProperties = [];
  bool _isLoading = true;
  String _selectedFilter = 'الكل';
  final List<String> _filters = ['الكل', 'شقق', 'فلل', 'شاليهات'];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await DataService.getAllProperties();
    setState(() {
      _saleProperties = all.where((p) => p['listingMode'] == 'for_sale').toList();
      _isLoading = false;
    });
  }

  List<Map<String, dynamic>> get _filtered {
    if (_selectedFilter == 'الكل') return _saleProperties;
    return _saleProperties.where((p) => p['type'] == _selectedFilter).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // ─── Hero Header ─────────────────────────────────
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            elevation: 0,
            backgroundColor: const Color(0xFFBCA374),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
            title: const Text('للبيع بعمولة إيليت', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset('assets/images/home3.jpg', fit: BoxFit.cover),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter, end: Alignment.bottomCenter,
                        colors: [const Color(0xFFBCA374).withOpacity(0.5), const Color(0xFFBCA374).withOpacity(0.95)],
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 60, left: 20, right: 20,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(color: const Color(0xFFD4AF37).withOpacity(0.2), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFD4AF37))),
                          child: const Text('عمولة تصل لـ 2% فقط — أقل من السوق بـ 60%', style: TextStyle(color: Color(0xFFD4AF37), fontSize: 11, fontWeight: FontWeight.bold)),
                        ),
                        const SizedBox(height: 8),
                        const Text('بيع عقارك بأسرع وقت\nبدون تعقيدات ووسطاء', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, height: 1.3)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(48),
              child: Container(
                color: const Color(0xFFBCA374),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: _filters.map((f) {
                      final isSel = _selectedFilter == f;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedFilter = f),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(right: 10),
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: isSel ? const Color(0xFFD4AF37) : Colors.white.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: isSel ? const Color(0xFFD4AF37) : Colors.white24),
                          ),
                          child: Text(f, style: TextStyle(color: isSel ? const Color(0xFFBCA374) : Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),

          // ─── Commission Advantage Banner ─────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFD4AF37), Color(0xFFB8962E)]),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.savings_rounded, color: Color(0xFFBCA374), size: 32),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('وفّر آلاف الجنيهات على عمولة البيع', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: const Color(0xFF1F2937))),
                          SizedBox(height: 4),
                          Text('نأخذ 1.5–2% فقط مقابل 4–5% في السوق. توثيق قانوني كامل.', style: TextStyle(fontSize: 12, color: const Color(0xFF4B5563))),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ─── Properties List ──────────────────────────────
          _isLoading
              ? const SliverFillRemaining(child: Center(child: CircularProgressIndicator()))
              : _filtered.isEmpty
                  ? const SliverFillRemaining(
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.search_off_rounded, size: 64, color: Colors.grey),
                            SizedBox(height: 16),
                            Text('لا توجد عقارات في هذه الفئة حالياً', style: TextStyle(color: Colors.grey)),
                          ],
                        ),
                      ),
                    )
                  : SliverPadding(
                      padding: const EdgeInsets.only(bottom: 40),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (context, index) => _buildSaleCard(_filtered[index]),
                          childCount: _filtered.length,
                        ),
                      ),
                    ),
        ],
      ),
    );
  }

  Widget _buildSaleCard(Map<String, dynamic> p) {
    final marketPrice = p['marketPrice'] ?? p['price'];
    final salePrice = p['price'];
    final commission = p['saleCommission'] ?? '2';

    // Compute savings
    String savings = '';
    try {
      final market = double.parse(marketPrice.toString().replaceAll(RegExp(r'[^0-9]'), ''));
      final sale = double.parse(salePrice.toString().replaceAll(RegExp(r'[^0-9]'), ''));
      final diff = market - sale;
      if (diff > 0) {
        savings = '${(diff / 1000).toStringAsFixed(0)}K وفر';
      }
    } catch (_) {}

    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PropertyDetailsScreen(property: p))),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color ?? Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [BoxShadow(color: const Color(0xFFD4AF37).withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 8))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image with badges
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  child: Image.asset(p['image'] as String? ?? 'assets/images/home1.jpg', height: 200, width: double.infinity, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(height: 200, color: Colors.grey.shade200, child: const Icon(Icons.home, size: 50, color: Colors.grey)),
                  ),
                ),
                // FOR SALE badge
                Positioned(
                  top: 14, right: 14,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(color: const Color(0xFFD4AF37), borderRadius: BorderRadius.circular(12)),
                    child: const Row(
                      children: [
                        Icon(Icons.sell_rounded, color: Color(0xFFBCA374), size: 14),
                        SizedBox(width: 4),
                        Text('للبيع', style: TextStyle(color: const Color(0xFF1F2937), fontWeight: FontWeight.w900, fontSize: 12)),
                      ],
                    ),
                  ),
                ),
                // Savings badge
                if (savings.isNotEmpty)
                  Positioned(
                    top: 14, left: 14,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(color: Colors.green, borderRadius: BorderRadius.circular(12)),
                      child: Text(savings, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                    ),
                  ),
                // Commission badge
                Positioned(
                  bottom: 14, right: 14,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.light ? Colors.white : const Color(0xFF334155), 
                      borderRadius: BorderRadius.circular(12)
                    ),
                    child: Text('عمولة $commission% فقط', style: TextStyle(color: Theme.of(context).brightness == Brightness.light ? const Color(0xFF1F2937) : Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    p['title'] as String? ?? '', 
                    style: TextStyle(
                      fontSize: 16, 
                      fontWeight: FontWeight.w900, 
                      color: Theme.of(context).textTheme.titleMedium?.color ?? AppTheme.textPrimary
                    ), 
                    maxLines: 2, 
                    overflow: TextOverflow.ellipsis
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.location_on_rounded, size: 14, color: Colors.grey),
                      const SizedBox(width: 4),
                      Expanded(child: Text(p['location'] as String? ?? '', style: const TextStyle(color: Colors.grey, fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  // Price comparison
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.light ? const Color(0xFFF8FAFF) : const Color(0xFF1E293B), 
                      borderRadius: BorderRadius.circular(12), 
                      border: Border.all(color: Theme.of(context).brightness == Brightness.light ? Colors.grey.shade200 : Colors.grey.shade800)
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('سعر كيو إيليت', style: TextStyle(color: Colors.grey, fontSize: 10)),
                              const SizedBox(height: 2),
                              FittedBox(
                                child: Text(
                                  '$salePrice ج.م', 
                                  style: TextStyle(
                                    color: Theme.of(context).textTheme.titleLarge?.color ?? AppTheme.textPrimary, 
                                    fontWeight: FontWeight.w900, 
                                    fontSize: 18
                                  )
                                )
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              const Text('السعر في السوق', style: TextStyle(color: Colors.grey, fontSize: 10)),
                              const SizedBox(height: 2),
                              FittedBox(child: Text('$marketPrice ج.م', style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, fontSize: 14, decoration: TextDecoration.lineThrough))),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Features
                  Row(
                    children: [
                      _feat(Icons.king_bed_rounded, '${p['beds']} غرف'),
                      const SizedBox(width: 12),
                      _feat(Icons.bathtub_rounded, '${p['baths']} حمام'),
                      const SizedBox(width: 12),
                      _feat(Icons.straighten_rounded, '${p['area']} م²'),
                    ],
                  ),
                  const SizedBox(height: 14),
                  // CTA
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PropertyDetailsScreen(property: p))),
                      icon: const Icon(Icons.contact_phone_rounded, size: 18),
                      label: const Text('تواصل مع مستشار البيع', style: TextStyle(fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFBCA374),
                        foregroundColor: const Color(0xFFD4AF37),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _feat(IconData icon, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: AppTheme.primaryColor),
        const SizedBox(width: 4),
        Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
      ],
    );
  }
}
